﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПП_3_курс
{
    public partial class addUsers : Form
    {
        public event Action addUsersAdded;
        public addUsers()
        {
            InitializeComponent();
        }

        private void addUsersButton_Click(object sender, EventArgs e)
        {
            // Подключение к базе данных
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // SQL запрос для вставки данных
                string query = "INSERT INTO Users (Username, PasswordHash, Role) VALUES (@Username, @PasswordHash, @Role)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Добавление параметров к команде
                    command.Parameters.AddWithValue("@Username", NameText.Text);
                    command.Parameters.AddWithValue("@PasswordHash", PasswordText.Text);
                    command.Parameters.AddWithValue("@Role", RoleText.Text);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            addUsersAdded.Invoke();
            Close();
        }
    }
}
