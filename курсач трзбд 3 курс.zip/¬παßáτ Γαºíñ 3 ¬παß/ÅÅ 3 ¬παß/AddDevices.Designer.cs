﻿namespace ПП_3_курс
{
    partial class AddDevices
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddDevices));
            LoanDate = new Label();
            Loan_add_button = new Button();
            ClientIDText = new ComboBox();
            label1 = new Label();
            ModelText = new TextBox();
            SuspendLayout();
            // 
            // LoanDate
            // 
            LoanDate.BackColor = Color.Cyan;
            LoanDate.BorderStyle = BorderStyle.FixedSingle;
            LoanDate.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            LoanDate.ForeColor = Color.White;
            LoanDate.Location = new Point(41, 38);
            LoanDate.Name = "LoanDate";
            LoanDate.Size = new Size(289, 29);
            LoanDate.TabIndex = 3;
            LoanDate.Text = "Введите номер клиента";
            LoanDate.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Loan_add_button
            // 
            Loan_add_button.BackColor = Color.Cyan;
            Loan_add_button.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Loan_add_button.ForeColor = Color.White;
            Loan_add_button.Location = new Point(41, 191);
            Loan_add_button.Name = "Loan_add_button";
            Loan_add_button.Size = new Size(289, 37);
            Loan_add_button.TabIndex = 10;
            Loan_add_button.Text = "Добавить";
            Loan_add_button.UseVisualStyleBackColor = false;
            Loan_add_button.Click += AddDevicesButton_Click;
            // 
            // ClientIDText
            // 
            ClientIDText.DropDownStyle = ComboBoxStyle.DropDownList;
            ClientIDText.FormattingEnabled = true;
            ClientIDText.Location = new Point(41, 70);
            ClientIDText.Name = "ClientIDText";
            ClientIDText.Size = new Size(289, 23);
            ClientIDText.TabIndex = 11;
            // 
            // label1
            // 
            label1.BackColor = Color.Cyan;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(41, 105);
            label1.Name = "label1";
            label1.Size = new Size(289, 35);
            label1.TabIndex = 12;
            label1.Text = "Введите модель устройства";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // ModelText
            // 
            ModelText.Location = new Point(41, 143);
            ModelText.Name = "ModelText";
            ModelText.Size = new Size(289, 23);
            ModelText.TabIndex = 13;
            // 
            // AddDevices
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(367, 377);
            Controls.Add(ModelText);
            Controls.Add(label1);
            Controls.Add(ClientIDText);
            Controls.Add(Loan_add_button);
            Controls.Add(LoanDate);
            ForeColor = Color.White;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AddDevices";
            Text = "Добавление устройства";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label LoanDate;
        private Button Loan_add_button;
        private ComboBox ClientIDText;
        private Label label1;
        private TextBox ModelText;
    }
}