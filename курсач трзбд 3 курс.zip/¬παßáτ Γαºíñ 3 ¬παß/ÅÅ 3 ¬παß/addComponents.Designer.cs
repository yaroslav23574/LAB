﻿namespace ПП_3_курс
{
    partial class addComponents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addComponents));
            Title = new Label();
            AuthorID = new Label();
            GenreID = new Label();
            Name_text = new TextBox();
            price_text = new TextBox();
            QuantityInStock_text = new TextBox();
            Add_book_new = new Button();
            SuspendLayout();
            // 
            // Title
            // 
            Title.BackColor = Color.Cyan;
            Title.BorderStyle = BorderStyle.FixedSingle;
            Title.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Title.ForeColor = Color.White;
            Title.Location = new Point(48, 46);
            Title.Name = "Title";
            Title.Size = new Size(326, 42);
            Title.TabIndex = 1;
            Title.Text = "Введите название компонента";
            Title.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // AuthorID
            // 
            AuthorID.BackColor = Color.Cyan;
            AuthorID.BorderStyle = BorderStyle.FixedSingle;
            AuthorID.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            AuthorID.ForeColor = Color.White;
            AuthorID.Location = new Point(48, 146);
            AuthorID.Name = "AuthorID";
            AuthorID.Size = new Size(326, 42);
            AuthorID.TabIndex = 2;
            AuthorID.Text = "Введите стоимость";
            AuthorID.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // GenreID
            // 
            GenreID.BackColor = Color.Cyan;
            GenreID.BorderStyle = BorderStyle.FixedSingle;
            GenreID.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            GenreID.ForeColor = Color.White;
            GenreID.Location = new Point(48, 247);
            GenreID.Name = "GenreID";
            GenreID.Size = new Size(326, 42);
            GenreID.TabIndex = 3;
            GenreID.Text = "Введите количество компонента ";
            GenreID.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Name_text
            // 
            Name_text.Font = new Font("Segoe UI", 14.25F);
            Name_text.Location = new Point(48, 91);
            Name_text.Name = "Name_text";
            Name_text.Size = new Size(326, 33);
            Name_text.TabIndex = 6;
            // 
            // price_text
            // 
            price_text.Font = new Font("Segoe UI", 14.25F);
            price_text.Location = new Point(48, 191);
            price_text.Name = "price_text";
            price_text.Size = new Size(326, 33);
            price_text.TabIndex = 7;
            // 
            // QuantityInStock_text
            // 
            QuantityInStock_text.Font = new Font("Segoe UI", 14.25F);
            QuantityInStock_text.Location = new Point(48, 292);
            QuantityInStock_text.Name = "QuantityInStock_text";
            QuantityInStock_text.Size = new Size(326, 33);
            QuantityInStock_text.TabIndex = 8;
            // 
            // Add_book_new
            // 
            Add_book_new.BackColor = Color.Cyan;
            Add_book_new.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Add_book_new.ForeColor = Color.White;
            Add_book_new.Location = new Point(48, 342);
            Add_book_new.Name = "Add_book_new";
            Add_book_new.Size = new Size(326, 49);
            Add_book_new.TabIndex = 10;
            Add_book_new.Text = "Добавить";
            Add_book_new.UseVisualStyleBackColor = false;
            Add_book_new.Click += Add_components_Click;
            // 
            // addComponents
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(436, 446);
            Controls.Add(Add_book_new);
            Controls.Add(QuantityInStock_text);
            Controls.Add(price_text);
            Controls.Add(Name_text);
            Controls.Add(GenreID);
            Controls.Add(AuthorID);
            Controls.Add(Title);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "addComponents";
            Text = "Добавление компонента";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label Title;
        private Label AuthorID;
        private Label GenreID;
        private TextBox Name_text;
        private TextBox price_text;
        private TextBox QuantityInStock_text;
        private Button Add_book_new;
    }
}