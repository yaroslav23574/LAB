﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПП_3_курс
{
    public partial class AddFaultTypes : Form
    {
        public event Action FaultTypesAdded;

        public AddFaultTypes()
        {
            InitializeComponent();
        }
        //addDescriptionText
        private void addDescriptionButton_Click(object sender, EventArgs e)
        {
            //получение значений из текстовых полей
            //int BookIDadd = int.Parse(ComponentID_text.Text);
            string AddDescriptionText = addDescriptionText.Text;

            // Подключение к базе данных
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // SQL запрос для вставки данных
                string query = "INSERT INTO FaultTypes (TypeDescription) VALUES (@TypeDescription)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Добавление параметров к команде
                    command.Parameters.AddWithValue("@TypeDescription", AddDescriptionText);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            FaultTypesAdded.Invoke();
            Close();
        }
    }
}
