﻿namespace ПП_3_курс
{
    partial class AddFaultTypes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            addDescriptionButton = new Button();
            addDescriptionText = new TextBox();
            Title = new Label();
            SuspendLayout();
            // 
            // addDescriptionButton
            // 
            addDescriptionButton.BackColor = Color.Cyan;
            addDescriptionButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            addDescriptionButton.ForeColor = Color.White;
            addDescriptionButton.Location = new Point(25, 131);
            addDescriptionButton.Name = "addDescriptionButton";
            addDescriptionButton.Size = new Size(326, 49);
            addDescriptionButton.TabIndex = 17;
            addDescriptionButton.Text = "Добавить";
            addDescriptionButton.UseVisualStyleBackColor = false;
            addDescriptionButton.Click += addDescriptionButton_Click;
            // 
            // addDescriptionText
            // 
            addDescriptionText.Font = new Font("Segoe UI", 14.25F);
            addDescriptionText.Location = new Point(25, 68);
            addDescriptionText.Name = "addDescriptionText";
            addDescriptionText.Size = new Size(326, 33);
            addDescriptionText.TabIndex = 14;
            // 
            // Title
            // 
            Title.BackColor = Color.Cyan;
            Title.BorderStyle = BorderStyle.FixedSingle;
            Title.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Title.ForeColor = Color.White;
            Title.Location = new Point(25, 23);
            Title.Name = "Title";
            Title.Size = new Size(326, 42);
            Title.TabIndex = 11;
            Title.Text = "Введите тип ошибки";
            Title.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // AddFaultTypes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(408, 309);
            Controls.Add(addDescriptionButton);
            Controls.Add(addDescriptionText);
            Controls.Add(Title);
            Name = "AddFaultTypes";
            Text = "AddFaultTypes";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button addDescriptionButton;
        private TextBox QuantityInStock_text;
        private TextBox price_text;
        private TextBox addDescriptionText;
        private Label GenreID;
        private Label AuthorID;
        private Label Title;
    }
}