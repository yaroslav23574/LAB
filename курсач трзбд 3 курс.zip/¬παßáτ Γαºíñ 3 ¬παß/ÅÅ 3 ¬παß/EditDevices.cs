﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПП_3_курс
{
    public partial class EditDevices : Form
    {
        private DataTable DevicesTable;
        private DataTable UsersTable;
        public event Action EditDevicesEdited;

        public EditDevices()
        {
            InitializeComponent();
            EditDevices_Load();
        }

        private void EditDevices_Load()
        {
            // Подключение к базе данных
            SqlConnection connection = new SqlConnection("Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;");
            string query = "SELECT DeviceID, ClientID, Model FROM Devices";
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            DevicesTable = new DataTable();
            adapter.Fill(DevicesTable);

            choice_device.DisplayMember = "DeviceID";
            choice_device.ValueMember = "DeviceID";
            choice_device.DataSource = DevicesTable;

            string userQuery = "SELECT UserID FROM Users";
            SqlDataAdapter userAdapter = new SqlDataAdapter(userQuery, connection);
            UsersTable = new DataTable();
            userAdapter.Fill(UsersTable);

            ClientIDText.DisplayMember = "UserID";
            ClientIDText.ValueMember = "UserID";
            ClientIDText.DataSource = UsersTable;
        }

        private void choiceDevices_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Получаем выбранную строку
            DataRowView selectedRow = (DataRowView)choice_device.SelectedItem;
            // Заполняем текстовые поля
            ClientIDText.SelectedValue = selectedRow["ClientID"].ToString();
            ModelText.Text = selectedRow["Model"].ToString();
        }

        private void EditDevices_button_Click(object sender, EventArgs e)
        {
            // Обновляем данные в базе данных
            SqlConnection connection = new SqlConnection("Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;");
            string updateQuery = "UPDATE Devices SET ClientID = @ClientID, Model = @Model WHERE DeviceID = @DeviceID";

            using (SqlCommand command = new SqlCommand(updateQuery, connection))
            {
                // Добавление параметров к команде
                command.Parameters.AddWithValue("@DeviceID", int.Parse(choice_device.Text));
                command.Parameters.AddWithValue("@ClientID", ClientIDText.SelectedValue);
                command.Parameters.AddWithValue("@Model", ModelText.Text);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

            EditDevices_Load();
            EditDevicesEdited?.Invoke();
            Close();
        }
    }
}
