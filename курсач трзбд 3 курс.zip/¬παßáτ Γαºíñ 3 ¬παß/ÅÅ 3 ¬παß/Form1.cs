using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;
using Microsoft.Data.SqlClient.Diagnostics;

namespace ПП_3_курс
{
    public partial class Main : Form
    {

        public Main()
        {
            InitializeComponent();
            Load += new EventHandler(Form_Load);

        }

        private void LoadData()
        {
            // Подключение к базе данных
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    while (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }
                }
                catch
                {
                    while (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }
                }


                // Запрос к таблице Components
                string queryCommponents = "SELECT ComponentID, Name, Price, QuantityInStock FROM Components";
                SqlDataAdapter ComponentsDataAdapter = new SqlDataAdapter(queryCommponents, connection);
                DataTable ComponentsDataTable = new DataTable();
                ComponentsDataAdapter.Fill(ComponentsDataTable); // Заполнение данными из базы данных
                Commponents_data.DataSource = ComponentsDataTable;
                Commponents_data.AutoGenerateColumns = true;
                Commponents_data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
                Commponents_data.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                Commponents_data.ReadOnly = true;

                // Запрос к таблице Devices
                string queryDevices = "SELECT DeviceID, ClientID, Model FROM Devices";
                SqlDataAdapter DevicesDataAdapter = new SqlDataAdapter(queryDevices, connection);
                DataTable DevicesDataTable = new DataTable();
                DevicesDataAdapter.Fill(DevicesDataTable); // Заполнение данными из базы данных
                Devices_data.DataSource = DevicesDataTable;
                Devices_data.AutoGenerateColumns = true;
                Devices_data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
                Devices_data.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                Devices_data.ReadOnly = true;

                // Запрос к таблице FaultTypes
                string queryFaultTypes = "SELECT FaultTypeID, TypeDescription FROM FaultTypes";
                SqlDataAdapter FaultTypesDataAdapter = new SqlDataAdapter(queryFaultTypes, connection);
                DataTable FaultTypesDataTable = new DataTable();
                FaultTypesDataAdapter.Fill(FaultTypesDataTable); // Заполнение данными из базы данных
                FaultTypes_data.DataSource = FaultTypesDataTable;
                FaultTypes_data.AutoGenerateColumns = true;
                FaultTypes_data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
                FaultTypes_data.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                FaultTypes_data.ReadOnly = true;

                // Запрос к таблице OrderComponents
                string queryOrderComponents = "SELECT OrderId, ComponentID, QuantityUsed FROM OrderComponents";
                SqlDataAdapter OrderComponentsDataAdapter = new SqlDataAdapter(queryOrderComponents, connection);
                DataTable OrderComponentsDataTable = new DataTable();
                OrderComponentsDataAdapter.Fill(OrderComponentsDataTable); // Заполнение данными из базы данных
                OrderComponents_data.DataSource = OrderComponentsDataTable;
                OrderComponents_data.AutoGenerateColumns = true;
                OrderComponents_data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
                OrderComponents_data.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                OrderComponents_data.ReadOnly = true;

                // Запрос к таблице RepairOrders
                string queryRepairOrders = "SELECT OrderID, DateOfAdmission, CompletionDate, Status, Cost, DeviceID, FaultTypeID FROM RepairOrders";
                SqlDataAdapter RepairOrdersDataAdapter = new SqlDataAdapter(queryRepairOrders, connection);
                DataTable RepairOrdersDataTable = new DataTable();
                RepairOrdersDataAdapter.Fill(RepairOrdersDataTable); // Заполнение данными из базы данных
                RepairOrders_data.DataSource = RepairOrdersDataTable;
                RepairOrders_data.AutoGenerateColumns = true;
                RepairOrders_data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
                RepairOrders_data.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                RepairOrders_data.ReadOnly = true;

                // Запрос к таблице Users
                string queryUsers = "SELECT UserID, Username, PasswordHash, Role FROM Users";
                SqlDataAdapter UsersDataAdapter = new SqlDataAdapter(queryUsers, connection);
                DataTable UsersDataTable = new DataTable();
                UsersDataAdapter.Fill(UsersDataTable); // Заполнение данными из базы данных
                Users_data.DataSource = UsersDataTable;
                Users_data.AutoGenerateColumns = true;
                Users_data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
                Users_data.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                Users_data.ReadOnly = true;
            }
        }

        private void Form_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void UpdateData()
        {
            LoadData();
        }

        private void Add_components_button_Click(object sender, EventArgs e)
        {
            addComponents add_components = new addComponents();
            add_components.ComponentAdded += UpdateData;
            add_components.ShowDialog();
        }

        private void Add_devices_button_Click(object sender, EventArgs e)
        {
            AddDevices add_devices = new AddDevices();
            add_devices.DevicesAdded += UpdateData;
            add_devices.ShowDialog();
        }

        private void Edit_RepairOrders_button_Click(object sender, EventArgs e)
        {
            editRepairOrders add_member = new editRepairOrders();
            add_member.RepairOrdersEdited += UpdateData;
            add_member.ShowDialog();
        }

        private void Edit_Components_button_Click(object sender, EventArgs e)
        {
            Edit_components Edit_member = new Edit_components();
            Edit_member.componentsEdited += UpdateData;
            Edit_member.ShowDialog();
        }

        private void deleteComponents_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            if (Commponents_data.SelectedRows.Count > 0)
            {
                int selectedComponentId = Convert.ToInt32(Commponents_data.SelectedRows[0].Cells["ComponentId"].Value);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Пытаемся удалить строку из Components
                            string deleteQuery = "DELETE FROM Components WHERE ComponentId = @ComponentId";
                            using (SqlCommand deleteCmd = new SqlCommand(deleteQuery, connection, transaction))
                            {
                                deleteCmd.Parameters.AddWithValue("@ComponentId", selectedComponentId);
                                deleteCmd.ExecuteNonQuery();
                            }
                            transaction.Commit();
                            LoadData();
                        }
                        catch (SqlException)
                        {
                            transaction.Rollback();
                        }
                    }
                }
            }
        }

        private void addRepairOrdersButton_Click(object sender, EventArgs e)
        {
            AddRepairOrders addRepairOrders = new AddRepairOrders();
            addRepairOrders.RepairOrdersAdded += UpdateData;
            addRepairOrders.ShowDialog();
        }

        private void deleteRepairOrdersbutton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            if (RepairOrders_data.SelectedRows.Count > 0)
            {
                int selectedOrderId = Convert.ToInt32(RepairOrders_data.SelectedRows[0].Cells["OrderID"].Value);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Удаляем строку из RepairOrders
                            string deleteQuery = "DELETE FROM RepairOrders WHERE OrderID = @OrderID";
                            using (SqlCommand deleteCmd = new SqlCommand(deleteQuery, connection, transaction))
                            {
                                deleteCmd.Parameters.AddWithValue("@OrderID", selectedOrderId);
                                deleteCmd.ExecuteNonQuery();
                            }
                            transaction.Commit();
                            LoadData();
                        }
                        catch (SqlException)
                        {
                            transaction.Rollback();
                        }
                    }
                }
            }
        }

        private void editDeviceButton_Click(object sender, EventArgs e)
        {
            EditDevices editdevices = new EditDevices();
            editdevices.EditDevicesEdited += UpdateData;
            editdevices.ShowDialog();
        }

        private void DeleteDevice_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            if (Devices_data.SelectedRows.Count > 0)
            {
                int selectedDeviceId = Convert.ToInt32(Devices_data.SelectedRows[0].Cells["DeviceID"].Value);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Пытаемся удалить строку из Devices
                            string deleteQuery = "DELETE FROM Devices WHERE DeviceID = @DeviceID";
                            using (SqlCommand deleteCmd = new SqlCommand(deleteQuery, connection, transaction))
                            {
                                deleteCmd.Parameters.AddWithValue("@DeviceID", selectedDeviceId);
                                deleteCmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            LoadData();
                        }
                        catch (SqlException)
                        {
                            transaction.Rollback();
                        }
                    }
                }
            }
        }

        private void addFaultTypeNutton_Click(object sender, EventArgs e)
        {
            AddFaultTypes addFaultTypes = new AddFaultTypes();
            addFaultTypes.FaultTypesAdded += UpdateData;
            addFaultTypes.ShowDialog();
        }

        private void DescriptionEditButton_Click(object sender, EventArgs e)
        {
            editFaultTypes EditFaultTypes = new editFaultTypes();
            EditFaultTypes.faultTypesEdited += UpdateData;
            EditFaultTypes.ShowDialog();
        }

        private void DescriptionDeleteButton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            if (FaultTypes_data.SelectedRows.Count > 0)
            {
                int selectedFaultTypesId = Convert.ToInt32(FaultTypes_data.SelectedRows[0].Cells["FaultTypeID"].Value);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Пытаемся удалить строку 
                            string deleteQuery = "DELETE FROM FaultTypes WHERE FaultTypeID = @FaultTypeID";
                            using (SqlCommand deleteCmd = new SqlCommand(deleteQuery, connection, transaction))
                            {
                                deleteCmd.Parameters.AddWithValue("@FaultTypeID", selectedFaultTypesId);
                                deleteCmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            LoadData();
                        }
                        catch (SqlException)
                        {
                            transaction.Rollback();
                        }
                    }
                }
            }
        }

        private void addOrderComponentsButton_Click(object sender, EventArgs e)
        {
            addOrderComponents AddOrderComponents = new addOrderComponents();
            AddOrderComponents.OrderComponentsAdded += UpdateData;
            AddOrderComponents.ShowDialog();
        }

        private void editOrderComponentsButton_Click(object sender, EventArgs e)
        {
            editOrderComponents EditOrderComponents = new editOrderComponents();
            EditOrderComponents.OrderComponentsEdited += UpdateData;
            EditOrderComponents.ShowDialog();
        }

        private void deleteOrderComponentsButton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            if (OrderComponents_data.SelectedRows.Count > 0)
            {
                int selectedOrderComponentsId = Convert.ToInt32(OrderComponents_data.SelectedRows[0].Cells["OrderID"].Value);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Пытаемся удалить строку 
                            string deleteQuery = "DELETE FROM OrderComponents WHERE OrderID = @OrderID";
                            using (SqlCommand deleteCmd = new SqlCommand(deleteQuery, connection, transaction))
                            {
                                deleteCmd.Parameters.AddWithValue("@OrderID", selectedOrderComponentsId);
                                deleteCmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            LoadData();
                        }
                        catch (SqlException)
                        {
                            transaction.Rollback();
                        }
                    }
                }
            }
        }

        private void addUsersButton_Click(object sender, EventArgs e)
        {
            addUsers AddUsers = new addUsers();
            AddUsers.addUsersAdded += UpdateData;
            AddUsers.ShowDialog();
        }

        private void editUsersButton_Click(object sender, EventArgs e)
        {
            editUsers EditUsers = new editUsers();
            EditUsers.editUsersEdited += UpdateData;
            EditUsers.ShowDialog();
        }

        private void deleteUsersButton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            if (Users_data.SelectedRows.Count > 0)
            {
                int selectedUserId = Convert.ToInt32(Users_data.SelectedRows[0].Cells["UserID"].Value);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Пытаемся удалить запись из таблицы Users
                            string deleteQuery = "DELETE FROM Users WHERE UserID = @UserID";
                            using (SqlCommand deleteCmd = new SqlCommand(deleteQuery, connection, transaction))
                            {
                                deleteCmd.Parameters.AddWithValue("@UserID", selectedUserId);
                                deleteCmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            LoadData(); 
                        }
                        catch (SqlException)
                        {
                            transaction.Rollback();
                        }
                    }
                }
            }
        }
    }
}
