﻿using Microsoft.Data.SqlClient;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПП_3_курс
{
    public partial class ClientForm : Form
    {
        private readonly int CurrentUserID;
        public ClientForm(int userID)
        {
            InitializeComponent();
            CurrentUserID = userID;
            LoadRepairOrders();
        }
        //ThisClientData

        public void LoadRepairOrders()
        {
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            string queryRepairOrders = "SELECT ro.OrderID, ro.DateOfAdmission, ro.CompletionDate, ro.Status, ro.Cost, ro.DeviceID, ro.FaultTypeID " +
                          "FROM RepairOrders AS ro " +
                          "WHERE ro.DeviceID IN (" +
                              "SELECT d.DeviceID " +
                              "FROM Devices AS d " +
                              "WHERE d.ClientID = @UserID" +
                          ") ORDER BY ro.DateOfAdmission DESC";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(queryRepairOrders, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", CurrentUserID); // Передаем ID пользователя

                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataTable table = new DataTable();
                            adapter.Fill(table);

                            // Привяжем данные к DataGridView
                            ThisClientData.DataSource = table;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void AddOrderButton_Click(object sender, EventArgs e)
        {
            AddOrderForm addOrderForm = new AddOrderForm(CurrentUserID, this);
            addOrderForm.ShowDialog();
        }
    }
}
