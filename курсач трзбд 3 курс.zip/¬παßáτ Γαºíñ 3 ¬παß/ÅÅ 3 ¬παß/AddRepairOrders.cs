﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПП_3_курс
{
    public partial class AddRepairOrders : Form
    {
        public event Action RepairOrdersAdded;

        private DataTable DevicesTable;
        private DataTable FaultTypeIDTable;
        public AddRepairOrders()
        {
            InitializeComponent();
            LoadAddRepairOrders();
        }

        private void LoadAddRepairOrders() 
        {
            SqlConnection connection = new SqlConnection("Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;");
            // Загрузка устройств
            string deviceQuery = "SELECT DeviceID FROM Devices";
            SqlDataAdapter deviceAdapter = new SqlDataAdapter(deviceQuery, connection);
            DataTable deviceTable = new DataTable();
            deviceAdapter.Fill(deviceTable);

            DeviceIDText.DisplayMember = "DeviceID";
            DeviceIDText.ValueMember = "DeviceID";
            DeviceIDText.DataSource = deviceTable;

            // Загрузка типов неисправностей
            string faultTypeQuery = "SELECT FaultTypeID FROM FaultTypes";
            SqlDataAdapter faultAdapter = new SqlDataAdapter(faultTypeQuery, connection);
            DataTable faultTypeTable = new DataTable();
            faultAdapter.Fill(faultTypeTable);

            FaultTypeIDText.DisplayMember = "FaultTypeID";
            FaultTypeIDText.ValueMember = "FaultTypeID";
            FaultTypeIDText.DataSource = faultTypeTable;
        }
        private void addRepairOrdersButton_Click(object sender, EventArgs e)
        {
            //получение значений из текстовых полей
            string DateOfAdmission = DateOfAdmiissionText.Text;
            string CompletionDate = CompletionDateText.Text;
            string Status = StatusText.Text;
            string Cost = CostText.Text;

            // Подключение к базе данных
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // SQL запрос для вставки данных
                string query = "INSERT INTO RepairOrders (DateOfAdmission, CompletionDate, Status, Cost, DeviceID, FaultTypeID) " +
                    "VALUES (@DateOfAdmission, @CompletionDate, @Status, @Cost, @DeviceID, @FaultTypeID)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Добавление параметров к команде
                    command.Parameters.AddWithValue("@DateOfAdmission", DateOfAdmission);
                    command.Parameters.AddWithValue("@CompletionDate", CompletionDate);
                    command.Parameters.AddWithValue("@Status", Status);
                    command.Parameters.AddWithValue("@Cost", Cost);
                    command.Parameters.AddWithValue("@DeviceID", DeviceIDText.SelectedValue);
                    command.Parameters.AddWithValue("@FaultTypeID", FaultTypeIDText.SelectedValue);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            RepairOrdersAdded.Invoke();
            Close();
        }
    }
}
