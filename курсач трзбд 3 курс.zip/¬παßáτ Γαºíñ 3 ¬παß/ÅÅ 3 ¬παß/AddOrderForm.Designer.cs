﻿namespace ПП_3_курс
{
    partial class AddOrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FaultTypeText = new ComboBox();
            label1 = new Label();
            addRepairOrdersButton = new Button();
            ModelText = new TextBox();
            label2 = new Label();
            SuspendLayout();
            // 
            // FaultTypeText
            // 
            FaultTypeText.DropDownStyle = ComboBoxStyle.DropDownList;
            FaultTypeText.FormattingEnabled = true;
            FaultTypeText.Location = new Point(32, 65);
            FaultTypeText.Name = "FaultTypeText";
            FaultTypeText.Size = new Size(332, 23);
            FaultTypeText.TabIndex = 28;
            // 
            // label1
            // 
            label1.BackColor = Color.Cyan;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(32, 26);
            label1.Name = "label1";
            label1.Size = new Size(332, 36);
            label1.TabIndex = 24;
            label1.Text = "Введите ошибку";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // addRepairOrdersButton
            // 
            addRepairOrdersButton.BackColor = Color.Cyan;
            addRepairOrdersButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            addRepairOrdersButton.ForeColor = Color.White;
            addRepairOrdersButton.Location = new Point(32, 198);
            addRepairOrdersButton.Name = "addRepairOrdersButton";
            addRepairOrdersButton.Size = new Size(332, 42);
            addRepairOrdersButton.TabIndex = 21;
            addRepairOrdersButton.Text = "добавить";
            addRepairOrdersButton.UseVisualStyleBackColor = false;
            addRepairOrdersButton.Click += addRepairOrdersButton_Click;
            // 
            // ModelText
            // 
            ModelText.Location = new Point(32, 143);
            ModelText.Name = "ModelText";
            ModelText.Size = new Size(332, 23);
            ModelText.TabIndex = 30;
            // 
            // label2
            // 
            label2.BackColor = Color.Cyan;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label2.ForeColor = Color.White;
            label2.Location = new Point(32, 105);
            label2.Name = "label2";
            label2.Size = new Size(332, 35);
            label2.TabIndex = 29;
            label2.Text = "Введите модель устройства";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // AddOrderForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(404, 307);
            Controls.Add(ModelText);
            Controls.Add(label2);
            Controls.Add(FaultTypeText);
            Controls.Add(label1);
            Controls.Add(addRepairOrdersButton);
            Name = "AddOrderForm";
            Text = "AddOrderForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox FaultTypeText;
        private Label label1;
        private Button addRepairOrdersButton;
        private TextBox ModelText;
        private Label label2;
    }
}