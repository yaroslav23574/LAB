﻿namespace ПП_3_курс
{
    partial class Edit_components
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Edit_components));
            choice_components = new ComboBox();
            choice = new Label();
            Description_edit_button = new Button();
            QuantiityInStock_edit_text = new TextBox();
            Price_edit_text = new TextBox();
            Name_edit_text = new TextBox();
            PhoneNumber = new Label();
            Surname = new Label();
            Member_name = new Label();
            SuspendLayout();
            // 
            // choice_components
            // 
            choice_components.DropDownStyle = ComboBoxStyle.DropDownList;
            choice_components.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            choice_components.FormattingEnabled = true;
            choice_components.Location = new Point(39, 54);
            choice_components.Name = "choice_components";
            choice_components.Size = new Size(431, 33);
            choice_components.TabIndex = 0;
            choice_components.SelectedIndexChanged += choice_components_SelectedIndexChanged;
            // 
            // choice
            // 
            choice.BackColor = Color.Cyan;
            choice.BorderStyle = BorderStyle.FixedSingle;
            choice.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            choice.ForeColor = Color.White;
            choice.Location = new Point(39, 20);
            choice.Name = "choice";
            choice.Size = new Size(431, 31);
            choice.TabIndex = 1;
            choice.Text = "Выберте компонент для редиктирования";
            choice.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Description_edit_button
            // 
            Description_edit_button.BackColor = Color.Cyan;
            Description_edit_button.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Description_edit_button.ForeColor = Color.White;
            Description_edit_button.Location = new Point(39, 357);
            Description_edit_button.Name = "Description_edit_button";
            Description_edit_button.Size = new Size(431, 33);
            Description_edit_button.TabIndex = 17;
            Description_edit_button.Text = "изменить";
            Description_edit_button.UseVisualStyleBackColor = false;
            Description_edit_button.Click += Components_edit_button_Click;
            // 
            // QuantiityInStock_edit_text
            // 
            QuantiityInStock_edit_text.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            QuantiityInStock_edit_text.Location = new Point(39, 307);
            QuantiityInStock_edit_text.Name = "QuantiityInStock_edit_text";
            QuantiityInStock_edit_text.Size = new Size(431, 33);
            QuantiityInStock_edit_text.TabIndex = 16;
            // 
            // Price_edit_text
            // 
            Price_edit_text.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Price_edit_text.Location = new Point(39, 222);
            Price_edit_text.Name = "Price_edit_text";
            Price_edit_text.Size = new Size(431, 33);
            Price_edit_text.TabIndex = 15;
            // 
            // Name_edit_text
            // 
            Name_edit_text.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Name_edit_text.Location = new Point(39, 137);
            Name_edit_text.Name = "Name_edit_text";
            Name_edit_text.Size = new Size(431, 33);
            Name_edit_text.TabIndex = 14;
            // 
            // PhoneNumber
            // 
            PhoneNumber.BackColor = Color.Cyan;
            PhoneNumber.BorderStyle = BorderStyle.FixedSingle;
            PhoneNumber.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            PhoneNumber.ForeColor = Color.White;
            PhoneNumber.Location = new Point(39, 273);
            PhoneNumber.Name = "PhoneNumber";
            PhoneNumber.Size = new Size(431, 31);
            PhoneNumber.TabIndex = 12;
            PhoneNumber.Text = "Введите колиество компонента на складе\r\n";
            PhoneNumber.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Surname
            // 
            Surname.BackColor = Color.Cyan;
            Surname.BorderStyle = BorderStyle.FixedSingle;
            Surname.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Surname.ForeColor = Color.White;
            Surname.Location = new Point(39, 186);
            Surname.Name = "Surname";
            Surname.Size = new Size(431, 33);
            Surname.TabIndex = 11;
            Surname.Text = "Введите цену компонента";
            Surname.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Member_name
            // 
            Member_name.BackColor = Color.Cyan;
            Member_name.BorderStyle = BorderStyle.FixedSingle;
            Member_name.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Member_name.ForeColor = Color.White;
            Member_name.Location = new Point(39, 100);
            Member_name.Name = "Member_name";
            Member_name.Size = new Size(431, 34);
            Member_name.TabIndex = 10;
            Member_name.Text = "Введите название компонента";
            Member_name.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Edit_components
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(518, 529);
            Controls.Add(Description_edit_button);
            Controls.Add(QuantiityInStock_edit_text);
            Controls.Add(Price_edit_text);
            Controls.Add(Name_edit_text);
            Controls.Add(PhoneNumber);
            Controls.Add(Surname);
            Controls.Add(Member_name);
            Controls.Add(choice);
            Controls.Add(choice_components);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Edit_components";
            Text = "Редактирование компонента";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox choice_components;
        private Label choice;
        private Button Description_edit_button;
        private TextBox QuantiityInStock_edit_text;
        private TextBox Price_edit_text;
        private TextBox Name_edit_text;
        private Label PhoneNumber;
        private Label Surname;
        private Label Member_name;
    }
}