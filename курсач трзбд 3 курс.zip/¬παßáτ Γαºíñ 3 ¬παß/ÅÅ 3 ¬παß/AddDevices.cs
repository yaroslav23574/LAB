﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПП_3_курс
{
    public partial class AddDevices : Form
    {
        public event Action DevicesAdded;

        private DataTable UsersTable;

        public AddDevices()
        {
            InitializeComponent();
            LoadAddDevices();
        }
        //ModelText
        private void LoadAddDevices()
        {
            SqlConnection connection = new SqlConnection("Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;");
            string userQuery = "SELECT UserID FROM Users";
            SqlDataAdapter userAdapter = new SqlDataAdapter(userQuery, connection);
            UsersTable = new DataTable();
            userAdapter.Fill(UsersTable);

            ClientIDText.DisplayMember = "UserID";
            ClientIDText.ValueMember = "UserID";
            ClientIDText.DataSource = UsersTable;
        }

        private void AddDevicesButton_Click(object sender, EventArgs e)
        {
            // Подключение к базе данных
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // SQL запрос для вставки данных
                string query = "INSERT INTO Devices (ClientID, Model) VALUES (@ClientID, @Model)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Добавление параметров к команде
                    command.Parameters.AddWithValue("@ClientID", ClientIDText.SelectedValue);
                    command.Parameters.AddWithValue("@Model", ModelText.Text);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            DevicesAdded.Invoke();
            Close();
        }
    }
}
