﻿using Microsoft.Data.SqlClient;
using System.Data;
using ПП_3_курс;

namespace ПП_3_курс
{
    public partial class editRepairOrders : Form
    {
        private SqlConnection connection;
        private DataTable RepairOrdersTable;

        public event Action RepairOrdersEdited;

        public editRepairOrders()
        {
            InitializeComponent();
            LoadRepairOrders();
        }

        private void LoadRepairOrders()
        {
            // Подключение к базе данных
            connection = new SqlConnection("Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;");
            string query = "SELECT OrderID, DateOfAdmission, CompletionDate, Status, Cost, DeviceID, FaultTypeID FROM RepairOrders";
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            RepairOrdersTable = new DataTable();
            adapter.Fill(RepairOrdersTable);

            choiceRepairOrders.DisplayMember = "OrderID";
            choiceRepairOrders.ValueMember = "OrderID";
            choiceRepairOrders.DataSource = RepairOrdersTable;

            // Загрузка устройств
            string deviceQuery = "SELECT DeviceID FROM Devices";
            SqlDataAdapter deviceAdapter = new SqlDataAdapter(deviceQuery, connection);
            DataTable deviceTable = new DataTable();
            deviceAdapter.Fill(deviceTable);

            DeviceIDBox.DisplayMember = "DeviceID";
            DeviceIDBox.ValueMember = "DeviceID";
            DeviceIDBox.DataSource = deviceTable;

            // Загрузка типов неисправностей
            string faultTypeQuery = "SELECT FaultTypeID FROM FaultTypes";
            SqlDataAdapter faultAdapter = new SqlDataAdapter(faultTypeQuery, connection);
            DataTable faultTypeTable = new DataTable();
            faultAdapter.Fill(faultTypeTable);

            FaultTypeIDBox.DisplayMember = "FaultTypeID";
            FaultTypeIDBox.ValueMember = "FaultTypeID";
            FaultTypeIDBox.DataSource = faultTypeTable;
        }

        private void choiceRepairOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Получаем выбранную строку
            DataRowView selectedRow = (DataRowView)choiceRepairOrders.SelectedItem;
            // Заполняем текстовые поля
            DateOfAdmiissionText.Text  = selectedRow["DateOfAdmission"].ToString();
            CompletionDateText.Text = selectedRow["CompletionDate"].ToString();
            StatusText.SelectedItem = selectedRow["Status"].ToString();
            CostText.Text = selectedRow["Cost"].ToString();
            DeviceIDBox.SelectedValue = selectedRow["DeviceID"].ToString();
            FaultTypeIDBox.SelectedValue = selectedRow["FaultTypeID"].ToString();
        }

        private void RepairOrders_edit_button_Click(object sender, EventArgs e)
        {
            int componentId = (int)choiceRepairOrders.SelectedValue;

            // Обновляем данные в базе данных
            string updateQuery = "UPDATE RepairOrders SET DateOfAdmission = @DateOfAdmission, CompletionDate = @CompletionDate, Status = @Status, Cost = @Cost," +
                "DeviceID = @DeviceID, FaultTypeID = @FaultTypeID  WHERE OrderID = @OrderID";

            using (SqlCommand command = new SqlCommand(updateQuery, connection))
            {
                // Добавление параметров к команде
                command.Parameters.AddWithValue("@OrderID", int.Parse(choiceRepairOrders.Text));
                command.Parameters.AddWithValue("@DateOfAdmission", DateOfAdmiissionText.Text);
                command.Parameters.AddWithValue("@CompletionDate", CompletionDateText.Text);
                command.Parameters.AddWithValue("@Status", StatusText.SelectedItem);
                command.Parameters.AddWithValue("@Cost", decimal.Parse(CostText.Text));
                command.Parameters.AddWithValue("@DeviceID", DeviceIDBox.SelectedValue);
                command.Parameters.AddWithValue("@FaultTypeID", FaultTypeIDBox.SelectedValue);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

            LoadRepairOrders();
            RepairOrdersEdited?.Invoke();
            Close();

        }
    }
}
