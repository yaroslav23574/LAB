﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ПП_3_курс
{
    public partial class Edit_components : Form
    {
        private SqlConnection connection;
        private DataTable componentsTable;

        public event Action componentsEdited;

        public Edit_components()
        {
            InitializeComponent();
            LoadComponents();
        }

        private void LoadComponents()
        {
            // Подключение к базе данных
            connection = new SqlConnection("Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;");
            string query = "SELECT ComponentID, Name, Price, QuantityInStock FROM Components";
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            componentsTable = new DataTable();
            adapter.Fill(componentsTable);

            choice_components.DisplayMember = "ComponentID";
            choice_components.ValueMember = "ComponentID";
            choice_components.DataSource = componentsTable;
        }

        private void choice_components_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Получаем выбранную строку
            DataRowView selectedRow = (DataRowView)choice_components.SelectedItem;
            // Заполняем текстовые поля
            Name_edit_text.Text = selectedRow["Name"].ToString();
            Price_edit_text.Text = selectedRow["Price"].ToString();
            QuantiityInStock_edit_text.Text = selectedRow["QuantityInStock"].ToString();
        }

        private void Components_edit_button_Click(object sender, EventArgs e)
        {
            // Получаем выбранный MemberID
            int componentId = (int)choice_components.SelectedValue;

            // Обновляем данные в базе данных
            string updateQuery = "UPDATE Components SET Name = @Name, Price = @Price, QuantityInStock = @QuantityInStock WHERE ComponentID = @ComponentID";

            using (SqlCommand command = new SqlCommand(updateQuery, connection))
            {
                // Добавление параметров к команде
                command.Parameters.AddWithValue("@ComponentID", int.Parse(choice_components.Text));
                command.Parameters.AddWithValue("@Name", Name_edit_text.Text);
                command.Parameters.AddWithValue("@Price", decimal.Parse(Price_edit_text.Text));
                command.Parameters.AddWithValue("@QuantityInStock", int.Parse(QuantiityInStock_edit_text.Text));

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

            LoadComponents();
            componentsEdited?.Invoke();
            Close();

        }
    }
}
