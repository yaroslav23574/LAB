﻿namespace ПП_3_курс
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LoginTextBox = new TextBox();
            PasswordTextBox = new TextBox();
            LoginButton = new RadioButton();
            RegButton = new RadioButton();
            ConfirmButton = new Button();
            AuthorID = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // LoginTextBox
            // 
            LoginTextBox.Location = new Point(39, 101);
            LoginTextBox.Name = "LoginTextBox";
            LoginTextBox.Size = new Size(236, 23);
            LoginTextBox.TabIndex = 1;
            // 
            // PasswordTextBox
            // 
            PasswordTextBox.Location = new Point(39, 178);
            PasswordTextBox.Name = "PasswordTextBox";
            PasswordTextBox.Size = new Size(236, 23);
            PasswordTextBox.TabIndex = 2;
            // 
            // LoginButton
            // 
            LoginButton.AutoSize = true;
            LoginButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            LoginButton.Location = new Point(39, 27);
            LoginButton.Name = "LoginButton";
            LoginButton.Size = new Size(77, 29);
            LoginButton.TabIndex = 6;
            LoginButton.TabStop = true;
            LoginButton.Text = "Вход";
            LoginButton.UseVisualStyleBackColor = true;
            // 
            // RegButton
            // 
            RegButton.AutoSize = true;
            RegButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            RegButton.Location = new Point(129, 27);
            RegButton.Name = "RegButton";
            RegButton.Size = new Size(146, 29);
            RegButton.TabIndex = 7;
            RegButton.TabStop = true;
            RegButton.Text = "Регистрация";
            RegButton.UseVisualStyleBackColor = true;
            // 
            // ConfirmButton
            // 
            ConfirmButton.BackColor = Color.Cyan;
            ConfirmButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            ConfirmButton.ForeColor = Color.White;
            ConfirmButton.Location = new Point(39, 221);
            ConfirmButton.Name = "ConfirmButton";
            ConfirmButton.Size = new Size(236, 37);
            ConfirmButton.TabIndex = 5;
            ConfirmButton.Text = "Войти";
            ConfirmButton.UseVisualStyleBackColor = false;
            ConfirmButton.Click += ConfirmButton_Click;
            // 
            // AuthorID
            // 
            AuthorID.BackColor = Color.Cyan;
            AuthorID.BorderStyle = BorderStyle.FixedSingle;
            AuthorID.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            AuthorID.ForeColor = Color.White;
            AuthorID.Location = new Point(39, 139);
            AuthorID.Name = "AuthorID";
            AuthorID.Size = new Size(236, 36);
            AuthorID.TabIndex = 32;
            AuthorID.Text = "Пароль";
            AuthorID.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            label1.BackColor = Color.Cyan;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(39, 66);
            label1.Name = "label1";
            label1.Size = new Size(236, 32);
            label1.TabIndex = 33;
            label1.Text = "Логин";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(324, 343);
            Controls.Add(label1);
            Controls.Add(AuthorID);
            Controls.Add(RegButton);
            Controls.Add(LoginButton);
            Controls.Add(ConfirmButton);
            Controls.Add(PasswordTextBox);
            Controls.Add(LoginTextBox);
            Name = "LoginForm";
            Text = "LoginForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox LoginTextBox;
        private TextBox PasswordTextBox;
        private RadioButton LoginButton;
        private RadioButton RegButton;
        private Button ConfirmButton;
        private Label AuthorID;
        private Label label1;
    }
}