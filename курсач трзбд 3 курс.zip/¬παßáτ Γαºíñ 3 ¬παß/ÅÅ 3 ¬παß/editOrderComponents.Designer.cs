﻿namespace ПП_3_курс
{
    partial class editOrderComponents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ComponentIDText = new ComboBox();
            OrderIDText = new ComboBox();
            QuantityUsedText = new TextBox();
            label2 = new Label();
            label3 = new Label();
            editOrdersComponentsButton = new Button();
            Surname = new Label();
            SuspendLayout();
            // 
            // ComponentIDText
            // 
            ComponentIDText.DropDownStyle = ComboBoxStyle.DropDownList;
            ComponentIDText.FormattingEnabled = true;
            ComponentIDText.Location = new Point(26, 169);
            ComponentIDText.Name = "ComponentIDText";
            ComponentIDText.Size = new Size(332, 23);
            ComponentIDText.TabIndex = 34;
            // 
            // OrderIDText
            // 
            OrderIDText.DropDownStyle = ComboBoxStyle.DropDownList;
            OrderIDText.FormattingEnabled = true;
            OrderIDText.Items.AddRange(new object[] { "Принят", "Исполняется", "Завершен" });
            OrderIDText.Location = new Point(26, 82);
            OrderIDText.Name = "OrderIDText";
            OrderIDText.Size = new Size(332, 23);
            OrderIDText.TabIndex = 33;
            OrderIDText.SelectedIndexChanged += OrderIDText_SelectedIndexChanged;
            // 
            // QuantityUsedText
            // 
            QuantityUsedText.Font = new Font("Segoe UI", 14.25F);
            QuantityUsedText.Location = new Point(26, 281);
            QuantityUsedText.Name = "QuantityUsedText";
            QuantityUsedText.Size = new Size(332, 33);
            QuantityUsedText.TabIndex = 32;
            // 
            // label2
            // 
            label2.BackColor = Color.Cyan;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label2.ForeColor = Color.White;
            label2.Location = new Point(26, 130);
            label2.Name = "label2";
            label2.Size = new Size(332, 36);
            label2.TabIndex = 31;
            label2.Text = "Введите ID компонента";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.BackColor = Color.Cyan;
            label3.BorderStyle = BorderStyle.FixedSingle;
            label3.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(26, 213);
            label3.Name = "label3";
            label3.Size = new Size(332, 65);
            label3.TabIndex = 30;
            label3.Text = "Введите количество используемого компонента";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // editOrdersComponentsButton
            // 
            editOrdersComponentsButton.BackColor = Color.Cyan;
            editOrdersComponentsButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            editOrdersComponentsButton.ForeColor = Color.White;
            editOrdersComponentsButton.Location = new Point(26, 343);
            editOrdersComponentsButton.Name = "editOrdersComponentsButton";
            editOrdersComponentsButton.Size = new Size(332, 42);
            editOrdersComponentsButton.TabIndex = 29;
            editOrdersComponentsButton.Text = "изменить";
            editOrdersComponentsButton.UseVisualStyleBackColor = false;
            editOrdersComponentsButton.Click += editOrdersComponentsButton_Click;
            // 
            // Surname
            // 
            Surname.BackColor = Color.Cyan;
            Surname.BorderStyle = BorderStyle.FixedSingle;
            Surname.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Surname.ForeColor = Color.White;
            Surname.Location = new Point(26, 43);
            Surname.Name = "Surname";
            Surname.Size = new Size(332, 36);
            Surname.TabIndex = 28;
            Surname.Text = "Введите ID заказа";
            Surname.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // editOrderComponents
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(416, 455);
            Controls.Add(ComponentIDText);
            Controls.Add(OrderIDText);
            Controls.Add(QuantityUsedText);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(editOrdersComponentsButton);
            Controls.Add(Surname);
            Name = "editOrderComponents";
            Text = "editOrderComponents";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox ComponentIDText;
        private ComboBox OrderIDText;
        private TextBox QuantityUsedText;
        private Label label2;
        private Label label3;
        private Button editOrdersComponentsButton;
        private Label Surname;
    }
}