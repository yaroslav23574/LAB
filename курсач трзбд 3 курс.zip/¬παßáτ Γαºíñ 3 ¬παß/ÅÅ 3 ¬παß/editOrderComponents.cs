﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПП_3_курс
{
    public partial class editOrderComponents : Form
    {
        private SqlConnection connection;
        private DataTable OrderComponentsTable;

        public event Action OrderComponentsEdited;

        public editOrderComponents()
        {
            InitializeComponent();
            LoadOrderComponents();
        }
        //OrderIDText
        //ComponentIDText
        //QuantityUsedText
        private void LoadOrderComponents()
        {
            // Подключение к базе данных
            connection = new SqlConnection("Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;");
            string query = "SELECT OrderID, ComponentID, QuantityUsed FROM OrderComponents";
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            OrderComponentsTable = new DataTable();
            adapter.Fill(OrderComponentsTable);

            OrderIDText.DisplayMember = "OrderID";
            OrderIDText.ValueMember = "OrderID";
            OrderIDText.DataSource = OrderComponentsTable;

            // Загрузка устройств
            string deviceQuery = "SELECT ComponentID FROM Components";
            SqlDataAdapter deviceAdapter = new SqlDataAdapter(deviceQuery, connection);
            DataTable deviceTable = new DataTable();
            deviceAdapter.Fill(deviceTable);

            ComponentIDText.DisplayMember = "ComponentID";
            ComponentIDText.ValueMember = "ComponentID";
            ComponentIDText.DataSource = deviceTable;

        }

        private void OrderIDText_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Получаем выбранную строку
            DataRowView selectedRow = (DataRowView)OrderIDText.SelectedItem;
            // Заполняем текстовые поля
            ComponentIDText.Text = selectedRow["ComponentID"].ToString();
            QuantityUsedText.Text = selectedRow["QuantityUsed"].ToString();
        }

        private void editOrdersComponentsButton_Click(object sender, EventArgs e)
        {
             //OrderID, ComponentID, QuantityUsed

            // Обновляем данные в базе данных
            string updateQuery = "UPDATE OrderComponents SET ComponentID = @ComponentID, QuantityUsed = @QuantityUsed WHERE OrderID = @OrderID";

            using (SqlCommand command = new SqlCommand(updateQuery, connection))
            {
                // Добавление параметров к команде
                command.Parameters.AddWithValue("@OrderID", int.Parse(OrderIDText.Text));
                command.Parameters.AddWithValue("@ComponentID", ComponentIDText.SelectedValue);
                command.Parameters.AddWithValue("@QuantityUsed", QuantityUsedText.Text);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

            LoadOrderComponents();
            OrderComponentsEdited?.Invoke();
            Close();
        }
    }
}
