﻿namespace ПП_3_курс
{
    partial class AddRepairOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddRepairOrders));
            AuthorID = new Label();
            Name_author = new Label();
            Surname = new Label();
            DateOfAdmiissionText = new TextBox();
            CompletionDateText = new TextBox();
            addRepairOrdersButton = new Button();
            CostText = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            StatusText = new ComboBox();
            DeviceIDText = new ComboBox();
            FaultTypeIDText = new ComboBox();
            SuspendLayout();
            // 
            // AuthorID
            // 
            AuthorID.BackColor = Color.Cyan;
            AuthorID.BorderStyle = BorderStyle.FixedSingle;
            AuthorID.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            AuthorID.ForeColor = Color.White;
            AuthorID.Location = new Point(34, 17);
            AuthorID.Name = "AuthorID";
            AuthorID.Size = new Size(332, 36);
            AuthorID.TabIndex = 0;
            AuthorID.Text = "Введите дату начала заказа";
            AuthorID.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Name_author
            // 
            Name_author.BackColor = Color.Cyan;
            Name_author.BorderStyle = BorderStyle.FixedSingle;
            Name_author.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Name_author.ForeColor = Color.White;
            Name_author.Location = new Point(34, 103);
            Name_author.Name = "Name_author";
            Name_author.Size = new Size(332, 36);
            Name_author.TabIndex = 1;
            Name_author.Text = "Введите дату окончания заказа";
            Name_author.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Surname
            // 
            Surname.BackColor = Color.Cyan;
            Surname.BorderStyle = BorderStyle.FixedSingle;
            Surname.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Surname.ForeColor = Color.White;
            Surname.Location = new Point(34, 189);
            Surname.Name = "Surname";
            Surname.Size = new Size(332, 36);
            Surname.TabIndex = 2;
            Surname.Text = "Введите статус заказа";
            Surname.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // DateOfAdmiissionText
            // 
            DateOfAdmiissionText.Font = new Font("Segoe UI", 14.25F);
            DateOfAdmiissionText.Location = new Point(34, 56);
            DateOfAdmiissionText.Name = "DateOfAdmiissionText";
            DateOfAdmiissionText.Size = new Size(332, 33);
            DateOfAdmiissionText.TabIndex = 3;
            // 
            // CompletionDateText
            // 
            CompletionDateText.Font = new Font("Segoe UI", 14.25F);
            CompletionDateText.Location = new Point(34, 142);
            CompletionDateText.Name = "CompletionDateText";
            CompletionDateText.Size = new Size(332, 33);
            CompletionDateText.TabIndex = 4;
            // 
            // addRepairOrdersButton
            // 
            addRepairOrdersButton.BackColor = Color.Cyan;
            addRepairOrdersButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            addRepairOrdersButton.ForeColor = Color.White;
            addRepairOrdersButton.Location = new Point(34, 535);
            addRepairOrdersButton.Name = "addRepairOrdersButton";
            addRepairOrdersButton.Size = new Size(332, 42);
            addRepairOrdersButton.TabIndex = 6;
            addRepairOrdersButton.Text = "добавить";
            addRepairOrdersButton.UseVisualStyleBackColor = false;
            addRepairOrdersButton.Click += addRepairOrdersButton_Click;
            // 
            // CostText
            // 
            CostText.Font = new Font("Segoe UI", 14.25F);
            CostText.Location = new Point(34, 317);
            CostText.Name = "CostText";
            CostText.Size = new Size(332, 33);
            CostText.TabIndex = 10;
            // 
            // label1
            // 
            label1.BackColor = Color.Cyan;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(34, 450);
            label1.Name = "label1";
            label1.Size = new Size(332, 36);
            label1.TabIndex = 9;
            label1.Text = "Введите ID ошибки";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.BackColor = Color.Cyan;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label2.ForeColor = Color.White;
            label2.Location = new Point(34, 364);
            label2.Name = "label2";
            label2.Size = new Size(332, 36);
            label2.TabIndex = 8;
            label2.Text = "Введите ID устройства";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.BackColor = Color.Cyan;
            label3.BorderStyle = BorderStyle.FixedSingle;
            label3.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(34, 278);
            label3.Name = "label3";
            label3.Size = new Size(332, 36);
            label3.TabIndex = 7;
            label3.Text = "Введите цену заказа";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // StatusText
            // 
            StatusText.DropDownStyle = ComboBoxStyle.DropDownList;
            StatusText.FormattingEnabled = true;
            StatusText.Items.AddRange(new object[] { "Принят", "Исполняется", "Завершен" });
            StatusText.Location = new Point(34, 228);
            StatusText.Name = "StatusText";
            StatusText.Size = new Size(332, 23);
            StatusText.TabIndex = 13;
            // 
            // DeviceIDText
            // 
            DeviceIDText.DropDownStyle = ComboBoxStyle.DropDownList;
            DeviceIDText.FormattingEnabled = true;
            DeviceIDText.Location = new Point(34, 403);
            DeviceIDText.Name = "DeviceIDText";
            DeviceIDText.Size = new Size(332, 23);
            DeviceIDText.TabIndex = 14;
            // 
            // FaultTypeIDText
            // 
            FaultTypeIDText.DropDownStyle = ComboBoxStyle.DropDownList;
            FaultTypeIDText.FormattingEnabled = true;
            FaultTypeIDText.Location = new Point(34, 489);
            FaultTypeIDText.Name = "FaultTypeIDText";
            FaultTypeIDText.Size = new Size(332, 23);
            FaultTypeIDText.TabIndex = 15;
            // 
            // AddRepairOrders
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(417, 613);
            Controls.Add(FaultTypeIDText);
            Controls.Add(DeviceIDText);
            Controls.Add(StatusText);
            Controls.Add(CostText);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(addRepairOrdersButton);
            Controls.Add(CompletionDateText);
            Controls.Add(DateOfAdmiissionText);
            Controls.Add(Surname);
            Controls.Add(Name_author);
            Controls.Add(AuthorID);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AddRepairOrders";
            Text = "Добавление нового заказа";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label AuthorID;
        private Label Name_author;
        private Label Surname;
        private TextBox DateOfAdmiissionText;
        private TextBox CompletionDateText;
        private Button addRepairOrdersButton;
        private TextBox CostText;
        private Label label1;
        private Label label2;
        private Label label3;
        private ComboBox StatusText;
        private ComboBox DeviceIDText;
        private ComboBox FaultTypeIDText;
    }
}