﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПП_3_курс
{
    public partial class addOrderComponents : Form
    {
        public event Action OrderComponentsAdded;

        private DataTable OrderComponentsTable;

        public addOrderComponents()
        {
            InitializeComponent();
            LoadAddOrderComponents();
        }
        //QuantityUsedText
        //ComponentIDText
        //OrderIDText
        private void LoadAddOrderComponents()
        {
            SqlConnection connection = new SqlConnection("Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;");
            string componentsQuery = "SELECT ComponentID FROM Components";
            SqlDataAdapter componentsAdapter = new SqlDataAdapter(componentsQuery, connection);
            DataTable componentsTable = new DataTable();
            componentsAdapter.Fill(componentsTable);

            ComponentIDText.DisplayMember = "ComponentID";
            ComponentIDText.ValueMember = "ComponentID";
            ComponentIDText.DataSource = componentsTable;

            string orderQuery = "SELECT OrderID FROM RepairOrders";
            SqlDataAdapter orderAdapter = new SqlDataAdapter(orderQuery, connection);
            DataTable orderTable = new DataTable();
            orderAdapter.Fill(orderTable);

            OrderIDText.DisplayMember = "OrderID";
            OrderIDText.ValueMember = "OrderID";
            OrderIDText.DataSource = orderTable;
        }

        private void addOrdersComponentsButton_Click(object sender, EventArgs e)
        {
            //получение значений из текстовых полей
            int quantityUsed = int.Parse(QuantityUsedText.Text);

            // Подключение к базе данных
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // SQL запрос для вставки данных
                string query = "INSERT INTO OrderComponents (OrderID, ComponentID, QuantityUsed) " +
                    "VALUES (@OrderID, @ComponentID, @QuantityUsed)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Добавление параметров к команде
                    command.Parameters.AddWithValue("OrderID", OrderIDText.SelectedValue);
                    command.Parameters.AddWithValue("@ComponentID", ComponentIDText.SelectedValue);
                    command.Parameters.AddWithValue("@QuantityUsed", quantityUsed);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            OrderComponentsAdded.Invoke();
            Close();
        }
    }
}
