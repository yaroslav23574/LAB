﻿namespace ПП_3_курс
{
    partial class addOrderComponents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ComponentIDText = new ComboBox();
            QuantityUsedText = new TextBox();
            label2 = new Label();
            label3 = new Label();
            addOrdersComponentsButton = new Button();
            OrderIDText = new ComboBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // ComponentIDText
            // 
            ComponentIDText.DropDownStyle = ComboBoxStyle.DropDownList;
            ComponentIDText.FormattingEnabled = true;
            ComponentIDText.Location = new Point(23, 151);
            ComponentIDText.Name = "ComponentIDText";
            ComponentIDText.Size = new Size(332, 23);
            ComponentIDText.TabIndex = 27;
            // 
            // QuantityUsedText
            // 
            QuantityUsedText.Font = new Font("Segoe UI", 14.25F);
            QuantityUsedText.Location = new Point(23, 263);
            QuantityUsedText.Name = "QuantityUsedText";
            QuantityUsedText.Size = new Size(332, 33);
            QuantityUsedText.TabIndex = 25;
            // 
            // label2
            // 
            label2.BackColor = Color.Cyan;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label2.ForeColor = Color.White;
            label2.Location = new Point(23, 112);
            label2.Name = "label2";
            label2.Size = new Size(332, 36);
            label2.TabIndex = 23;
            label2.Text = "Введите ID компонента";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.BackColor = Color.Cyan;
            label3.BorderStyle = BorderStyle.FixedSingle;
            label3.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(23, 195);
            label3.Name = "label3";
            label3.Size = new Size(332, 65);
            label3.TabIndex = 22;
            label3.Text = "Введите количество используемого компонента";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // addOrdersComponentsButton
            // 
            addOrdersComponentsButton.BackColor = Color.Cyan;
            addOrdersComponentsButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            addOrdersComponentsButton.ForeColor = Color.White;
            addOrdersComponentsButton.Location = new Point(23, 325);
            addOrdersComponentsButton.Name = "addOrdersComponentsButton";
            addOrdersComponentsButton.Size = new Size(332, 42);
            addOrdersComponentsButton.TabIndex = 21;
            addOrdersComponentsButton.Text = "добавить";
            addOrdersComponentsButton.UseVisualStyleBackColor = false;
            addOrdersComponentsButton.Click += addOrdersComponentsButton_Click;
            // 
            // OrderIDText
            // 
            OrderIDText.DropDownStyle = ComboBoxStyle.DropDownList;
            OrderIDText.FormattingEnabled = true;
            OrderIDText.Location = new Point(23, 65);
            OrderIDText.Name = "OrderIDText";
            OrderIDText.Size = new Size(332, 23);
            OrderIDText.TabIndex = 29;
            // 
            // label1
            // 
            label1.BackColor = Color.Cyan;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(23, 26);
            label1.Name = "label1";
            label1.Size = new Size(332, 36);
            label1.TabIndex = 28;
            label1.Text = "Введите ID заказа";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // addOrderComponents
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(406, 403);
            Controls.Add(OrderIDText);
            Controls.Add(label1);
            Controls.Add(ComponentIDText);
            Controls.Add(QuantityUsedText);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(addOrdersComponentsButton);
            Name = "addOrderComponents";
            Text = "addOrderComponents";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private ComboBox ComponentIDText;
        private TextBox QuantityUsedText;
        private Label label2;
        private Label label3;
        private Button addOrdersComponentsButton;
        private ComboBox OrderIDText;
        private Label label1;
    }
}