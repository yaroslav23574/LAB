﻿namespace ПП_3_курс
{
    partial class Main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle10 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle11 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle12 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            Commponents_data = new DataGridView();
            Add_components_button = new Button();
            Add_device_button = new Button();
            Devices_data = new DataGridView();
            OrderComponents_data = new DataGridView();
            FaultTypes_data = new DataGridView();
            mainBindingSource = new BindingSource(components);
            mainBindingSource1 = new BindingSource(components);
            RepairOrders_data = new DataGridView();
            Users_data = new DataGridView();
            Repair = new TabPage();
            deleteRepairOrdersbutton = new Button();
            editRepairOrdersButton = new Button();
            addRepairOrdersButton = new Button();
            Comp = new TabPage();
            deleteComponents = new Button();
            Edit_Components_button = new Button();
            tabControlMain = new TabControl();
            Dev = new TabPage();
            DeleteDevice = new Button();
            editDeviceButton = new Button();
            Fault = new TabPage();
            addFaultTypeNutton = new Button();
            DescriptionDeleteButton = new Button();
            DescriptionEditButton = new Button();
            OrderComp = new TabPage();
            addOrderComponentsButton = new Button();
            deleteOrderComponentsButton = new Button();
            editOrderComponentsButton = new Button();
            User = new TabPage();
            addUsersButton = new Button();
            deleteUsersButton = new Button();
            editUsersButton = new Button();
            ((System.ComponentModel.ISupportInitialize)Commponents_data).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Devices_data).BeginInit();
            ((System.ComponentModel.ISupportInitialize)OrderComponents_data).BeginInit();
            ((System.ComponentModel.ISupportInitialize)FaultTypes_data).BeginInit();
            ((System.ComponentModel.ISupportInitialize)mainBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)mainBindingSource1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)RepairOrders_data).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Users_data).BeginInit();
            Repair.SuspendLayout();
            Comp.SuspendLayout();
            tabControlMain.SuspendLayout();
            Dev.SuspendLayout();
            Fault.SuspendLayout();
            OrderComp.SuspendLayout();
            User.SuspendLayout();
            SuspendLayout();
            // 
            // Commponents_data
            // 
            dataGridViewCellStyle1.BackColor = Color.FromArgb(192, 255, 255);
            Commponents_data.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            Commponents_data.BackgroundColor = Color.FromArgb(224, 224, 224);
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.Cyan;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle2.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            Commponents_data.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            Commponents_data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Commponents_data.Location = new Point(32, 22);
            Commponents_data.Name = "Commponents_data";
            Commponents_data.Size = new Size(645, 196);
            Commponents_data.TabIndex = 1;
            // 
            // Add_components_button
            // 
            Add_components_button.BackColor = Color.Cyan;
            Add_components_button.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            Add_components_button.ForeColor = Color.White;
            Add_components_button.Location = new Point(32, 224);
            Add_components_button.Name = "Add_components_button";
            Add_components_button.Size = new Size(141, 50);
            Add_components_button.TabIndex = 2;
            Add_components_button.Text = "Добавить ";
            Add_components_button.UseVisualStyleBackColor = false;
            Add_components_button.Click += Add_components_button_Click;
            // 
            // Add_device_button
            // 
            Add_device_button.BackColor = Color.Cyan;
            Add_device_button.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            Add_device_button.ForeColor = Color.White;
            Add_device_button.Location = new Point(18, 248);
            Add_device_button.Name = "Add_device_button";
            Add_device_button.Size = new Size(205, 50);
            Add_device_button.TabIndex = 4;
            Add_device_button.Text = "Добавить ";
            Add_device_button.UseVisualStyleBackColor = false;
            Add_device_button.Click += Add_devices_button_Click;
            // 
            // Devices_data
            // 
            dataGridViewCellStyle3.BackColor = Color.FromArgb(192, 255, 255);
            Devices_data.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            Devices_data.BackgroundColor = Color.FromArgb(224, 224, 224);
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = Color.Cyan;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            Devices_data.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            Devices_data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Devices_data.Location = new Point(18, 46);
            Devices_data.Name = "Devices_data";
            Devices_data.Size = new Size(668, 196);
            Devices_data.TabIndex = 6;
            // 
            // OrderComponents_data
            // 
            dataGridViewCellStyle5.BackColor = Color.FromArgb(192, 255, 255);
            OrderComponents_data.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            OrderComponents_data.BackgroundColor = Color.FromArgb(224, 224, 224);
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.Cyan;
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            OrderComponents_data.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            OrderComponents_data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            OrderComponents_data.Location = new Point(21, 23);
            OrderComponents_data.Name = "OrderComponents_data";
            OrderComponents_data.Size = new Size(666, 196);
            OrderComponents_data.TabIndex = 10;
            // 
            // FaultTypes_data
            // 
            dataGridViewCellStyle7.BackColor = Color.FromArgb(192, 255, 255);
            FaultTypes_data.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            FaultTypes_data.BackgroundColor = Color.FromArgb(224, 224, 224);
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = Color.Cyan;
            dataGridViewCellStyle8.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle8.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.True;
            FaultTypes_data.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            FaultTypes_data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            FaultTypes_data.Location = new Point(19, 72);
            FaultTypes_data.Name = "FaultTypes_data";
            FaultTypes_data.Size = new Size(659, 196);
            FaultTypes_data.TabIndex = 11;
            // 
            // mainBindingSource
            // 
            mainBindingSource.DataSource = typeof(Main);
            // 
            // mainBindingSource1
            // 
            mainBindingSource1.DataSource = typeof(Main);
            // 
            // RepairOrders_data
            // 
            dataGridViewCellStyle9.BackColor = Color.FromArgb(192, 255, 255);
            RepairOrders_data.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            RepairOrders_data.BackgroundColor = Color.FromArgb(224, 224, 224);
            dataGridViewCellStyle10.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = Color.Cyan;
            dataGridViewCellStyle10.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle10.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = Color.IndianRed;
            dataGridViewCellStyle10.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = DataGridViewTriState.True;
            RepairOrders_data.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            RepairOrders_data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            RepairOrders_data.Location = new Point(6, 29);
            RepairOrders_data.Name = "RepairOrders_data";
            RepairOrders_data.Size = new Size(738, 196);
            RepairOrders_data.TabIndex = 18;
            // 
            // Users_data
            // 
            dataGridViewCellStyle11.BackColor = Color.FromArgb(192, 255, 255);
            Users_data.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            Users_data.BackgroundColor = Color.FromArgb(224, 224, 224);
            dataGridViewCellStyle12.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = Color.Cyan;
            dataGridViewCellStyle12.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle12.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = DataGridViewTriState.True;
            Users_data.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            Users_data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Users_data.Location = new Point(19, 24);
            Users_data.Name = "Users_data";
            Users_data.Size = new Size(658, 196);
            Users_data.TabIndex = 22;
            // 
            // Repair
            // 
            Repair.Controls.Add(deleteRepairOrdersbutton);
            Repair.Controls.Add(editRepairOrdersButton);
            Repair.Controls.Add(addRepairOrdersButton);
            Repair.Controls.Add(RepairOrders_data);
            Repair.Location = new Point(4, 24);
            Repair.Name = "Repair";
            Repair.Padding = new Padding(3);
            Repair.Size = new Size(760, 394);
            Repair.TabIndex = 1;
            Repair.Text = "Заказы";
            Repair.UseVisualStyleBackColor = true;
            // 
            // deleteRepairOrdersbutton
            // 
            deleteRepairOrdersbutton.BackColor = Color.Cyan;
            deleteRepairOrdersbutton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            deleteRepairOrdersbutton.ForeColor = Color.White;
            deleteRepairOrdersbutton.Location = new Point(395, 231);
            deleteRepairOrdersbutton.Name = "deleteRepairOrdersbutton";
            deleteRepairOrdersbutton.Size = new Size(141, 50);
            deleteRepairOrdersbutton.TabIndex = 26;
            deleteRepairOrdersbutton.Text = "Удалить ";
            deleteRepairOrdersbutton.UseVisualStyleBackColor = false;
            deleteRepairOrdersbutton.Click += deleteRepairOrdersbutton_Click;
            // 
            // editRepairOrdersButton
            // 
            editRepairOrdersButton.BackColor = Color.Cyan;
            editRepairOrdersButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            editRepairOrdersButton.ForeColor = Color.White;
            editRepairOrdersButton.Location = new Point(159, 231);
            editRepairOrdersButton.Name = "editRepairOrdersButton";
            editRepairOrdersButton.Size = new Size(230, 50);
            editRepairOrdersButton.TabIndex = 25;
            editRepairOrdersButton.Text = "Редактировать";
            editRepairOrdersButton.UseVisualStyleBackColor = false;
            editRepairOrdersButton.Click += Edit_RepairOrders_button_Click;
            // 
            // addRepairOrdersButton
            // 
            addRepairOrdersButton.BackColor = Color.Cyan;
            addRepairOrdersButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            addRepairOrdersButton.ForeColor = Color.White;
            addRepairOrdersButton.Location = new Point(12, 231);
            addRepairOrdersButton.Name = "addRepairOrdersButton";
            addRepairOrdersButton.Size = new Size(141, 50);
            addRepairOrdersButton.TabIndex = 24;
            addRepairOrdersButton.Text = "Добавить ";
            addRepairOrdersButton.UseVisualStyleBackColor = false;
            addRepairOrdersButton.Click += addRepairOrdersButton_Click;
            // 
            // Comp
            // 
            Comp.Controls.Add(deleteComponents);
            Comp.Controls.Add(Edit_Components_button);
            Comp.Controls.Add(Commponents_data);
            Comp.Controls.Add(Add_components_button);
            Comp.Location = new Point(4, 24);
            Comp.Name = "Comp";
            Comp.Padding = new Padding(3);
            Comp.Size = new Size(760, 394);
            Comp.TabIndex = 0;
            Comp.Text = "Компоненты";
            Comp.UseVisualStyleBackColor = true;
            // 
            // deleteComponents
            // 
            deleteComponents.BackColor = Color.Cyan;
            deleteComponents.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            deleteComponents.ForeColor = Color.White;
            deleteComponents.Location = new Point(415, 224);
            deleteComponents.Name = "deleteComponents";
            deleteComponents.Size = new Size(141, 50);
            deleteComponents.TabIndex = 23;
            deleteComponents.Text = "Удалить ";
            deleteComponents.UseVisualStyleBackColor = false;
            deleteComponents.Click += deleteComponents_Click;
            // 
            // Edit_Components_button
            // 
            Edit_Components_button.BackColor = Color.Cyan;
            Edit_Components_button.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Edit_Components_button.ForeColor = Color.White;
            Edit_Components_button.Location = new Point(179, 224);
            Edit_Components_button.Name = "Edit_Components_button";
            Edit_Components_button.Size = new Size(230, 50);
            Edit_Components_button.TabIndex = 22;
            Edit_Components_button.Text = "Редактировать";
            Edit_Components_button.UseVisualStyleBackColor = false;
            Edit_Components_button.Click += Edit_Components_button_Click;
            // 
            // tabControlMain
            // 
            tabControlMain.Controls.Add(Comp);
            tabControlMain.Controls.Add(Repair);
            tabControlMain.Controls.Add(Dev);
            tabControlMain.Controls.Add(Fault);
            tabControlMain.Controls.Add(OrderComp);
            tabControlMain.Controls.Add(User);
            tabControlMain.Location = new Point(12, 12);
            tabControlMain.Name = "tabControlMain";
            tabControlMain.SelectedIndex = 0;
            tabControlMain.Size = new Size(768, 422);
            tabControlMain.TabIndex = 23;
            // 
            // Dev
            // 
            Dev.Controls.Add(DeleteDevice);
            Dev.Controls.Add(editDeviceButton);
            Dev.Controls.Add(Add_device_button);
            Dev.Controls.Add(Devices_data);
            Dev.Location = new Point(4, 24);
            Dev.Name = "Dev";
            Dev.Size = new Size(760, 394);
            Dev.TabIndex = 2;
            Dev.Text = "Устройства";
            Dev.UseVisualStyleBackColor = true;
            // 
            // DeleteDevice
            // 
            DeleteDevice.BackColor = Color.Cyan;
            DeleteDevice.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            DeleteDevice.ForeColor = Color.White;
            DeleteDevice.Location = new Point(465, 248);
            DeleteDevice.Name = "DeleteDevice";
            DeleteDevice.Size = new Size(141, 50);
            DeleteDevice.TabIndex = 29;
            DeleteDevice.Text = "Удалить ";
            DeleteDevice.UseVisualStyleBackColor = false;
            DeleteDevice.Click += DeleteDevice_Click;
            // 
            // editDeviceButton
            // 
            editDeviceButton.BackColor = Color.Cyan;
            editDeviceButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            editDeviceButton.ForeColor = Color.White;
            editDeviceButton.Location = new Point(229, 248);
            editDeviceButton.Name = "editDeviceButton";
            editDeviceButton.Size = new Size(230, 50);
            editDeviceButton.TabIndex = 28;
            editDeviceButton.Text = "Редактировать";
            editDeviceButton.UseVisualStyleBackColor = false;
            editDeviceButton.Click += editDeviceButton_Click;
            // 
            // Fault
            // 
            Fault.Controls.Add(addFaultTypeNutton);
            Fault.Controls.Add(DescriptionDeleteButton);
            Fault.Controls.Add(DescriptionEditButton);
            Fault.Controls.Add(FaultTypes_data);
            Fault.Location = new Point(4, 24);
            Fault.Name = "Fault";
            Fault.Size = new Size(760, 394);
            Fault.TabIndex = 3;
            Fault.Text = "Ошибки";
            Fault.UseVisualStyleBackColor = true;
            // 
            // addFaultTypeNutton
            // 
            addFaultTypeNutton.BackColor = Color.Cyan;
            addFaultTypeNutton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            addFaultTypeNutton.ForeColor = Color.White;
            addFaultTypeNutton.Location = new Point(19, 274);
            addFaultTypeNutton.Name = "addFaultTypeNutton";
            addFaultTypeNutton.Size = new Size(205, 50);
            addFaultTypeNutton.TabIndex = 32;
            addFaultTypeNutton.Text = "Добавить ";
            addFaultTypeNutton.UseVisualStyleBackColor = false;
            addFaultTypeNutton.Click += addFaultTypeNutton_Click;
            // 
            // DescriptionDeleteButton
            // 
            DescriptionDeleteButton.BackColor = Color.Cyan;
            DescriptionDeleteButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            DescriptionDeleteButton.ForeColor = Color.White;
            DescriptionDeleteButton.Location = new Point(466, 274);
            DescriptionDeleteButton.Name = "DescriptionDeleteButton";
            DescriptionDeleteButton.Size = new Size(141, 50);
            DescriptionDeleteButton.TabIndex = 31;
            DescriptionDeleteButton.Text = "Удалить ";
            DescriptionDeleteButton.UseVisualStyleBackColor = false;
            DescriptionDeleteButton.Click += DescriptionDeleteButton_Click;
            // 
            // DescriptionEditButton
            // 
            DescriptionEditButton.BackColor = Color.Cyan;
            DescriptionEditButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            DescriptionEditButton.ForeColor = Color.White;
            DescriptionEditButton.Location = new Point(230, 274);
            DescriptionEditButton.Name = "DescriptionEditButton";
            DescriptionEditButton.Size = new Size(230, 50);
            DescriptionEditButton.TabIndex = 30;
            DescriptionEditButton.Text = "Редактировать";
            DescriptionEditButton.UseVisualStyleBackColor = false;
            DescriptionEditButton.Click += DescriptionEditButton_Click;
            // 
            // OrderComp
            // 
            OrderComp.Controls.Add(addOrderComponentsButton);
            OrderComp.Controls.Add(deleteOrderComponentsButton);
            OrderComp.Controls.Add(editOrderComponentsButton);
            OrderComp.Controls.Add(OrderComponents_data);
            OrderComp.Location = new Point(4, 24);
            OrderComp.Name = "OrderComp";
            OrderComp.Size = new Size(760, 394);
            OrderComp.TabIndex = 4;
            OrderComp.Text = "Компоненты заказов";
            OrderComp.UseVisualStyleBackColor = true;
            // 
            // addOrderComponentsButton
            // 
            addOrderComponentsButton.BackColor = Color.Cyan;
            addOrderComponentsButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            addOrderComponentsButton.ForeColor = Color.White;
            addOrderComponentsButton.Location = new Point(21, 234);
            addOrderComponentsButton.Name = "addOrderComponentsButton";
            addOrderComponentsButton.Size = new Size(205, 50);
            addOrderComponentsButton.TabIndex = 35;
            addOrderComponentsButton.Text = "Добавить ";
            addOrderComponentsButton.UseVisualStyleBackColor = false;
            addOrderComponentsButton.Click += addOrderComponentsButton_Click;
            // 
            // deleteOrderComponentsButton
            // 
            deleteOrderComponentsButton.BackColor = Color.Cyan;
            deleteOrderComponentsButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            deleteOrderComponentsButton.ForeColor = Color.White;
            deleteOrderComponentsButton.Location = new Point(468, 234);
            deleteOrderComponentsButton.Name = "deleteOrderComponentsButton";
            deleteOrderComponentsButton.Size = new Size(141, 50);
            deleteOrderComponentsButton.TabIndex = 34;
            deleteOrderComponentsButton.Text = "Удалить ";
            deleteOrderComponentsButton.UseVisualStyleBackColor = false;
            deleteOrderComponentsButton.Click += deleteOrderComponentsButton_Click;
            // 
            // editOrderComponentsButton
            // 
            editOrderComponentsButton.BackColor = Color.Cyan;
            editOrderComponentsButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            editOrderComponentsButton.ForeColor = Color.White;
            editOrderComponentsButton.Location = new Point(232, 234);
            editOrderComponentsButton.Name = "editOrderComponentsButton";
            editOrderComponentsButton.Size = new Size(230, 50);
            editOrderComponentsButton.TabIndex = 33;
            editOrderComponentsButton.Text = "Редактировать";
            editOrderComponentsButton.UseVisualStyleBackColor = false;
            editOrderComponentsButton.Click += editOrderComponentsButton_Click;
            // 
            // User
            // 
            User.Controls.Add(addUsersButton);
            User.Controls.Add(deleteUsersButton);
            User.Controls.Add(editUsersButton);
            User.Controls.Add(Users_data);
            User.Location = new Point(4, 24);
            User.Name = "User";
            User.Size = new Size(760, 394);
            User.TabIndex = 5;
            User.Text = "Пользователи";
            User.UseVisualStyleBackColor = true;
            // 
            // addUsersButton
            // 
            addUsersButton.BackColor = Color.Cyan;
            addUsersButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            addUsersButton.ForeColor = Color.White;
            addUsersButton.Location = new Point(18, 239);
            addUsersButton.Name = "addUsersButton";
            addUsersButton.Size = new Size(205, 50);
            addUsersButton.TabIndex = 38;
            addUsersButton.Text = "Добавить ";
            addUsersButton.UseVisualStyleBackColor = false;
            addUsersButton.Click += addUsersButton_Click;
            // 
            // deleteUsersButton
            // 
            deleteUsersButton.BackColor = Color.Cyan;
            deleteUsersButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            deleteUsersButton.ForeColor = Color.White;
            deleteUsersButton.Location = new Point(465, 239);
            deleteUsersButton.Name = "deleteUsersButton";
            deleteUsersButton.Size = new Size(141, 50);
            deleteUsersButton.TabIndex = 37;
            deleteUsersButton.Text = "Удалить ";
            deleteUsersButton.UseVisualStyleBackColor = false;
            deleteUsersButton.Click += deleteUsersButton_Click;
            // 
            // editUsersButton
            // 
            editUsersButton.BackColor = Color.Cyan;
            editUsersButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            editUsersButton.ForeColor = Color.White;
            editUsersButton.Location = new Point(229, 239);
            editUsersButton.Name = "editUsersButton";
            editUsersButton.Size = new Size(230, 50);
            editUsersButton.TabIndex = 36;
            editUsersButton.Text = "Редактировать";
            editUsersButton.UseVisualStyleBackColor = false;
            editUsersButton.Click += editUsersButton_Click;
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(792, 461);
            Controls.Add(tabControlMain);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            ForeColor = Color.Black;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Main";
            Text = "Сервис ремонта ПК";
            ((System.ComponentModel.ISupportInitialize)Commponents_data).EndInit();
            ((System.ComponentModel.ISupportInitialize)Devices_data).EndInit();
            ((System.ComponentModel.ISupportInitialize)OrderComponents_data).EndInit();
            ((System.ComponentModel.ISupportInitialize)FaultTypes_data).EndInit();
            ((System.ComponentModel.ISupportInitialize)mainBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)mainBindingSource1).EndInit();
            ((System.ComponentModel.ISupportInitialize)RepairOrders_data).EndInit();
            ((System.ComponentModel.ISupportInitialize)Users_data).EndInit();
            Repair.ResumeLayout(false);
            Comp.ResumeLayout(false);
            tabControlMain.ResumeLayout(false);
            Dev.ResumeLayout(false);
            Fault.ResumeLayout(false);
            OrderComp.ResumeLayout(false);
            User.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private DataGridView Commponents_data;
        private Button Add_components_button;
        private Button Add_device_button;
        private DataGridView Devices_data;
        private DataGridView OrderComponents_data;
        private DataGridView FaultTypes_data;
        private BindingSource mainBindingSource;
        private BindingSource mainBindingSource1;
        private DataGridView RepairOrders_data;
        private Label Commponents;
        private DataGridView Users_data;
        private TabPage Repair;
        private TabPage Comp;
        private TabControl tabControlMain;
        private TabPage Dev;
        private TabPage Fault;
        private TabPage OrderComp;
        private TabPage User;
        private Button Edit_Components_button;
        private Button deleteComponents;
        private Button deleteRepairOrdersbutton;
        private Button editRepairOrdersButton;
        private Button addRepairOrdersButton;
        private Button DeleteDevice;
        private Button editDeviceButton;
        private Button DescriptionDeleteButton;
        private Button DescriptionEditButton;
        private Button addFaultTypeNutton;
        private Button addOrderComponentsButton;
        private Button deleteOrderComponentsButton;
        private Button editOrderComponentsButton;
        private Button addUsersButton;
        private Button deleteUsersButton;
        private Button editUsersButton;
    }
}
