﻿namespace ПП_3_курс
{
    partial class editRepairOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(editRepairOrders));
            StatusText = new ComboBox();
            CostText = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            CompletionDateText = new TextBox();
            DateOfAdmiissionText = new TextBox();
            label4 = new Label();
            Name_author = new Label();
            AuthorID = new Label();
            choice = new Label();
            choiceRepairOrders = new ComboBox();
            Member_edit_button = new Button();
            DeviceIDBox = new ComboBox();
            FaultTypeIDBox = new ComboBox();
            SuspendLayout();
            // 
            // StatusText
            // 
            StatusText.DropDownStyle = ComboBoxStyle.DropDownList;
            StatusText.FormattingEnabled = true;
            StatusText.Items.AddRange(new object[] { "Принят", "Исполняется", "Завершен" });
            StatusText.Location = new Point(12, 303);
            StatusText.Name = "StatusText";
            StatusText.Size = new Size(378, 23);
            StatusText.TabIndex = 25;
            // 
            // CostText
            // 
            CostText.Font = new Font("Segoe UI", 14.25F);
            CostText.Location = new Point(12, 392);
            CostText.Name = "CostText";
            CostText.Size = new Size(378, 33);
            CostText.TabIndex = 22;
            // 
            // label1
            // 
            label1.BackColor = Color.Cyan;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(12, 525);
            label1.Name = "label1";
            label1.Size = new Size(378, 36);
            label1.TabIndex = 21;
            label1.Text = "Введите ID ошибки";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.BackColor = Color.Cyan;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label2.ForeColor = Color.White;
            label2.Location = new Point(12, 439);
            label2.Name = "label2";
            label2.Size = new Size(378, 36);
            label2.TabIndex = 20;
            label2.Text = "Введите ID устройства";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.BackColor = Color.Cyan;
            label3.BorderStyle = BorderStyle.FixedSingle;
            label3.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(12, 353);
            label3.Name = "label3";
            label3.Size = new Size(378, 36);
            label3.TabIndex = 19;
            label3.Text = "Введите цену заказа";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // CompletionDateText
            // 
            CompletionDateText.Font = new Font("Segoe UI", 14.25F);
            CompletionDateText.Location = new Point(12, 217);
            CompletionDateText.Name = "CompletionDateText";
            CompletionDateText.Size = new Size(378, 33);
            CompletionDateText.TabIndex = 18;
            // 
            // DateOfAdmiissionText
            // 
            DateOfAdmiissionText.Font = new Font("Segoe UI", 14.25F);
            DateOfAdmiissionText.Location = new Point(12, 131);
            DateOfAdmiissionText.Name = "DateOfAdmiissionText";
            DateOfAdmiissionText.Size = new Size(378, 33);
            DateOfAdmiissionText.TabIndex = 17;
            // 
            // label4
            // 
            label4.BackColor = Color.Cyan;
            label4.BorderStyle = BorderStyle.FixedSingle;
            label4.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label4.ForeColor = Color.White;
            label4.Location = new Point(12, 264);
            label4.Name = "label4";
            label4.Size = new Size(378, 36);
            label4.TabIndex = 16;
            label4.Text = "Введите статус заказа";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Name_author
            // 
            Name_author.BackColor = Color.Cyan;
            Name_author.BorderStyle = BorderStyle.FixedSingle;
            Name_author.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Name_author.ForeColor = Color.White;
            Name_author.Location = new Point(12, 178);
            Name_author.Name = "Name_author";
            Name_author.Size = new Size(378, 36);
            Name_author.TabIndex = 15;
            Name_author.Text = "Введите дату окончания заказа";
            Name_author.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // AuthorID
            // 
            AuthorID.BackColor = Color.Cyan;
            AuthorID.BorderStyle = BorderStyle.FixedSingle;
            AuthorID.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            AuthorID.ForeColor = Color.White;
            AuthorID.Location = new Point(12, 92);
            AuthorID.Name = "AuthorID";
            AuthorID.Size = new Size(378, 36);
            AuthorID.TabIndex = 14;
            AuthorID.Text = "Введите дату начала заказа";
            AuthorID.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // choice
            // 
            choice.BackColor = Color.Cyan;
            choice.BorderStyle = BorderStyle.FixedSingle;
            choice.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            choice.ForeColor = Color.White;
            choice.Location = new Point(12, 9);
            choice.Name = "choice";
            choice.Size = new Size(378, 31);
            choice.TabIndex = 27;
            choice.Text = "Выберте заказ для редиктирования";
            choice.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // choiceRepairOrders
            // 
            choiceRepairOrders.DropDownStyle = ComboBoxStyle.DropDownList;
            choiceRepairOrders.Font = new Font("Segoe UI", 14.25F);
            choiceRepairOrders.FormattingEnabled = true;
            choiceRepairOrders.Location = new Point(12, 43);
            choiceRepairOrders.Name = "choiceRepairOrders";
            choiceRepairOrders.Size = new Size(378, 33);
            choiceRepairOrders.TabIndex = 26;
            choiceRepairOrders.SelectedIndexChanged += choiceRepairOrders_SelectedIndexChanged;
            // 
            // Member_edit_button
            // 
            Member_edit_button.BackColor = Color.Cyan;
            Member_edit_button.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            Member_edit_button.ForeColor = Color.White;
            Member_edit_button.Location = new Point(12, 603);
            Member_edit_button.Name = "Member_edit_button";
            Member_edit_button.Size = new Size(378, 33);
            Member_edit_button.TabIndex = 28;
            Member_edit_button.Text = "изменить";
            Member_edit_button.UseVisualStyleBackColor = false;
            Member_edit_button.Click += RepairOrders_edit_button_Click;
            // 
            // DeviceIDBox
            // 
            DeviceIDBox.DropDownStyle = ComboBoxStyle.DropDownList;
            DeviceIDBox.FormattingEnabled = true;
            DeviceIDBox.Location = new Point(12, 478);
            DeviceIDBox.Name = "DeviceIDBox";
            DeviceIDBox.Size = new Size(378, 23);
            DeviceIDBox.TabIndex = 29;
            // 
            // FaultTypeIDBox
            // 
            FaultTypeIDBox.DropDownStyle = ComboBoxStyle.DropDownList;
            FaultTypeIDBox.FormattingEnabled = true;
            FaultTypeIDBox.Location = new Point(12, 564);
            FaultTypeIDBox.Name = "FaultTypeIDBox";
            FaultTypeIDBox.Size = new Size(378, 23);
            FaultTypeIDBox.TabIndex = 30;
            // 
            // editRepairOrders
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(444, 714);
            Controls.Add(FaultTypeIDBox);
            Controls.Add(DeviceIDBox);
            Controls.Add(Member_edit_button);
            Controls.Add(choice);
            Controls.Add(choiceRepairOrders);
            Controls.Add(StatusText);
            Controls.Add(CostText);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(CompletionDateText);
            Controls.Add(DateOfAdmiissionText);
            Controls.Add(label4);
            Controls.Add(Name_author);
            Controls.Add(AuthorID);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "editRepairOrders";
            Text = "редактирование заказа";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private ComboBox StatusText;
        private TextBox CostText;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox CompletionDateText;
        private TextBox DateOfAdmiissionText;
        private Label label4;
        private Label Name_author;
        private Label AuthorID;
        private Label choice;
        private ComboBox choiceRepairOrders;
        private Button Member_edit_button;
        private ComboBox DeviceIDBox;
        private ComboBox FaultTypeIDBox;
    }
}