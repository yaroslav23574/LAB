﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПП_3_курс
{
    public partial class AddOrderForm : Form
    {
        private readonly ClientForm parentForm;
        private readonly int userID;
        public AddOrderForm(int CurrentUserID, ClientForm parent)
        {
            InitializeComponent();

            userID = CurrentUserID;
            parentForm = parent;

            LoadFaultTypes();
        }
        //FaultTypeText ModelText
        private void LoadFaultTypes()
        {
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            // Загрузка данных из базы данных
            string faultTypeQuery = "SELECT FaultTypeID, TypeDescription  FROM FaultTypes";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(faultTypeQuery, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable faultTypeTable = new DataTable();
                        adapter.Fill(faultTypeTable);

                        // Устанавливаем источник данных для ComboBox
                        FaultTypeText.DisplayMember = "TypeDescription"; // Название неисправности
                        FaultTypeText.ValueMember = "FaultTypeID"; // Идентификатор неисправности
                        FaultTypeText.DataSource = faultTypeTable;
                    }
                }
            }
        }

        private void addRepairOrdersButton_Click(object sender, EventArgs e)
        {
            // Формируем SQL-запрос
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            // Первый запрос: вставка устройства
            string query2 = "INSERT INTO Devices(ClientID, Model) OUTPUT INSERTED.DeviceID VALUES(@ClientID, @Model)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query2, connection))
                {
                    // Добавляем параметры к первому запросу
                    command.Parameters.AddWithValue("@Model", ModelText.Text);
                    command.Parameters.AddWithValue("@ClientID", userID);

                    // Выполняем первый запрос и получаем ID только что созданного устройства
                    int newDeviceID = (int)command.ExecuteScalar();

                    // Второй запрос: вставка ремонтного заказа
                    string query = "INSERT INTO RepairOrders (DateOfAdmission, CompletionDate, Status, Cost, DeviceID, FaultTypeID)" +
                                  "VALUES(@DateOfAdmission, @CompletionDate, @Status, @Cost, @DeviceID, @FaultTypeID)";

                    using (SqlCommand secondCommand = new SqlCommand(query, connection))
                    {
                        // Генерация даты поступления и завершения
                        DateTime dateOfAdmission = DateTime.Now;
                        DateTime completionDate = dateOfAdmission.AddDays(7);
                        Random random = new Random();
                        decimal cost = random.Next(5000, 10001); // Случайная стоимость от 5000 до 10000 рублей

                        // Добавляем параметры ко второму запросу
                        secondCommand.Parameters.AddWithValue("@DateOfAdmission", dateOfAdmission);
                        secondCommand.Parameters.AddWithValue("@CompletionDate", completionDate);
                        secondCommand.Parameters.AddWithValue("@Status", "Принят");
                        secondCommand.Parameters.AddWithValue("@Cost", cost);
                        secondCommand.Parameters.AddWithValue("@DeviceID", newDeviceID); // Используем полученный DeviceID
                        secondCommand.Parameters.AddWithValue("@FaultTypeID", FaultTypeText.SelectedValue);

                        // Выполняем второй запрос
                        secondCommand.ExecuteNonQuery();
                    }
                }
            }

            parentForm.LoadRepairOrders();
            Close();
        }
    }
}
