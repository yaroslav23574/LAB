﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПП_3_курс
{
    public partial class editUsers : Form
    {
        private SqlConnection connection;
        private DataTable editUsersTable;

        public event Action editUsersEdited;
        public editUsers()
        {
            InitializeComponent();
            LoadUsers();
        }
        //choiceUsers
        //NameText
        //PasswordText
        //RoleText

        private void LoadUsers()
        {
            // Подключение к базе данных
            connection = new SqlConnection("Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;");
            string query = "SELECT UserID, Username, PasswordHash, Role FROM Users";
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            editUsersTable = new DataTable();
            adapter.Fill(editUsersTable);

            choiceUsers.DisplayMember = "UserID";
            choiceUsers.ValueMember = "UserID";
            choiceUsers.DataSource = editUsersTable;

        }

        private void choiceUsers_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Получаем выбранную строку
            DataRowView selectedRow = (DataRowView)choiceUsers.SelectedItem;
            // Заполняем текстовые поля
            NameText.Text = selectedRow["Username"].ToString();
            PasswordText.Text = selectedRow["PasswordHash"].ToString();
            RoleText.SelectedItem = selectedRow["Role"].ToString();
        }

        private void editUsersButton_Click(object sender, EventArgs e)
        {
            // Обновляем данные в базе данных
            string updateQuery = "UPDATE Users SET Username = @Username, PasswordHash = @PasswordHash, Role = @Role WHERE UserID = @UserID";

            using (SqlCommand command = new SqlCommand(updateQuery, connection))
            {
                // Добавление параметров к команде
                command.Parameters.AddWithValue("@UserID", int.Parse(choiceUsers.Text));
                command.Parameters.AddWithValue("@Username", NameText.Text);
                command.Parameters.AddWithValue("@PasswordHash", PasswordText.Text);
                command.Parameters.AddWithValue("@Role", RoleText.SelectedItem);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

            LoadUsers();
            editUsersEdited?.Invoke();
            Close();

        }
    }
}
