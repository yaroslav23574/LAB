﻿namespace ПП_3_курс
{
    partial class addUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            RoleText = new ComboBox();
            label2 = new Label();
            addUsersButton = new Button();
            PasswordText = new TextBox();
            NameText = new TextBox();
            PasswordTextsdf = new Label();
            AuthorID = new Label();
            SuspendLayout();
            // 
            // RoleText
            // 
            RoleText.DropDownStyle = ComboBoxStyle.DropDownList;
            RoleText.FormattingEnabled = true;
            RoleText.Items.AddRange(new object[] { "Администратор", "Клиент" });
            RoleText.Location = new Point(28, 224);
            RoleText.Name = "RoleText";
            RoleText.Size = new Size(332, 23);
            RoleText.TabIndex = 27;
            // 
            // label2
            // 
            label2.BackColor = Color.Cyan;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label2.ForeColor = Color.White;
            label2.Location = new Point(28, 185);
            label2.Name = "label2";
            label2.Size = new Size(332, 36);
            label2.TabIndex = 23;
            label2.Text = "Введите роль";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // addUsersButton
            // 
            addUsersButton.BackColor = Color.Cyan;
            addUsersButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            addUsersButton.ForeColor = Color.White;
            addUsersButton.Location = new Point(28, 268);
            addUsersButton.Name = "addUsersButton";
            addUsersButton.Size = new Size(332, 42);
            addUsersButton.TabIndex = 21;
            addUsersButton.Text = "добавить";
            addUsersButton.UseVisualStyleBackColor = false;
            addUsersButton.Click += addUsersButton_Click;
            // 
            // PasswordText
            // 
            PasswordText.Font = new Font("Segoe UI", 14.25F);
            PasswordText.Location = new Point(28, 134);
            PasswordText.Name = "PasswordText";
            PasswordText.Size = new Size(332, 33);
            PasswordText.TabIndex = 20;
            // 
            // NameText
            // 
            NameText.Font = new Font("Segoe UI", 14.25F);
            NameText.Location = new Point(28, 48);
            NameText.Name = "NameText";
            NameText.Size = new Size(332, 33);
            NameText.TabIndex = 19;
            // 
            // PasswordTextsdf
            // 
            PasswordTextsdf.BackColor = Color.Cyan;
            PasswordTextsdf.BorderStyle = BorderStyle.FixedSingle;
            PasswordTextsdf.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            PasswordTextsdf.ForeColor = Color.White;
            PasswordTextsdf.Location = new Point(28, 95);
            PasswordTextsdf.Name = "PasswordTextsdf";
            PasswordTextsdf.Size = new Size(332, 36);
            PasswordTextsdf.TabIndex = 17;
            PasswordTextsdf.Text = "Введите пароль";
            PasswordTextsdf.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // AuthorID
            // 
            AuthorID.BackColor = Color.Cyan;
            AuthorID.BorderStyle = BorderStyle.FixedSingle;
            AuthorID.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            AuthorID.ForeColor = Color.White;
            AuthorID.Location = new Point(28, 9);
            AuthorID.Name = "AuthorID";
            AuthorID.Size = new Size(332, 36);
            AuthorID.TabIndex = 16;
            AuthorID.Text = "Введите имя";
            AuthorID.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // addUsers
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(418, 368);
            Controls.Add(RoleText);
            Controls.Add(label2);
            Controls.Add(addUsersButton);
            Controls.Add(PasswordText);
            Controls.Add(NameText);
            Controls.Add(PasswordTextsdf);
            Controls.Add(AuthorID);
            Name = "addUsers";
            Text = "addUsers";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox RoleText;
        private Label label2;
        private Button addUsersButton;
        private TextBox PasswordText;
        private TextBox NameText;
        private Label PasswordTextsdf;
        private Label AuthorID;
    }
}