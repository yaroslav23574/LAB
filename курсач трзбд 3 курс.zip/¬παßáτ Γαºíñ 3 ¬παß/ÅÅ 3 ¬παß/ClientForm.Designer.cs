﻿namespace ПП_3_курс
{
    partial class ClientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            AddOrderButton = new Button();
            ThisClientData = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)ThisClientData).BeginInit();
            SuspendLayout();
            // 
            // AddOrderButton
            // 
            AddOrderButton.BackColor = Color.Cyan;
            AddOrderButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            AddOrderButton.ForeColor = Color.White;
            AddOrderButton.Location = new Point(477, 343);
            AddOrderButton.Name = "AddOrderButton";
            AddOrderButton.Size = new Size(278, 50);
            AddOrderButton.TabIndex = 39;
            AddOrderButton.Text = "Сделать заказ";
            AddOrderButton.UseVisualStyleBackColor = false;
            AddOrderButton.Click += AddOrderButton_Click;
            // 
            // ThisClientData
            // 
            dataGridViewCellStyle3.BackColor = Color.FromArgb(192, 255, 255);
            ThisClientData.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            ThisClientData.BackgroundColor = Color.FromArgb(224, 224, 224);
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = Color.Cyan;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            ThisClientData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            ThisClientData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            ThisClientData.Location = new Point(28, 39);
            ThisClientData.Name = "ThisClientData";
            ThisClientData.Size = new Size(727, 285);
            ThisClientData.TabIndex = 40;
            // 
            // ClientForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(800, 450);
            Controls.Add(ThisClientData);
            Controls.Add(AddOrderButton);
            Name = "ClientForm";
            Text = "ClientForm";
            ((System.ComponentModel.ISupportInitialize)ThisClientData).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Button AddOrderButton;
        private DataGridView ThisClientData;
    }
}