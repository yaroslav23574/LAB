﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace ПП_3_курс
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            LoginButton.Checked = true;
        }
        //PasswordTextBox
        //LoginTextBox
        //RegButton
        //LoginButton
        //ConfirmButton
        private void ConfirmButton_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            if (LoginButton.Checked) // Пользователь выбрал войти
            {
                // Авторизация пользователя
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    try
                    {
                        conn.Open();

                        // Используем параметризованный запрос, но теперь возвращаем UserID вместе с ролью
                        string loginQuery = "SELECT UserID, Role FROM Users WHERE Username=@username AND PasswordHash=@passwordhash";

                        using (SqlCommand cmd = new SqlCommand(loginQuery, conn))
                        {
                            cmd.Parameters.AddWithValue("@username", LoginTextBox.Text);

                            // Получаем хэш пароля для сравнения
                            string hashedPassword = GetHashedPassword(PasswordTextBox.Text);
                            cmd.Parameters.AddWithValue("@passwordhash", hashedPassword);

                            using (SqlDataReader reader = cmd.ExecuteReader())
                            {
                                if (reader.Read()) // Чтение первой строки
                                {
                                    int userID = Convert.ToInt32(reader["UserID"]); // Получаем UserID
                                    string role = reader["Role"].ToString(); // Получаем роль

                                    switch (role)
                                    {
                                        case "Администратор":
                                            Main main = new Main();
                                            main.ShowDialog();
                                            break;

                                        case "Клиент":
                                            // Передаём UserID в ClientForm
                                            ClientForm clientForm = new ClientForm(userID);
                                            clientForm.ShowDialog();
                                            break;

                                        default:
                                            MessageBox.Show("Ошибка авторизации");
                                            break;
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}");
                    }
                }
            }
            else if (RegButton.Checked) // Пользователь хочет зарегистрироваться
            {
                // Регистрация нового пользователя остаётся прежней
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    try
                    {
                        conn.Open();

                        // Генерируем хэш для пароля
                        string hashedPassword = GetHashedPassword(PasswordTextBox.Text);

                        // Параметризованная команда добавления пользователя
                        string insertUserQuery = "INSERT INTO Users (Username, PasswordHash, Role) VALUES (@username, @passwordhash, 'Клиент')";

                        using (SqlCommand cmd = new SqlCommand(insertUserQuery, conn))
                        {
                            cmd.Parameters.AddWithValue("@username", LoginTextBox.Text);
                            cmd.Parameters.AddWithValue("@passwordhash", hashedPassword);

                            int rowsAffected = cmd.ExecuteNonQuery();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}");
                    }
                }
            }
        }

        private static string GetHashedPassword(string input)
        {
            using (SHA256 sha256Hasher = SHA256.Create())
            {
                byte[] data = sha256Hasher.ComputeHash(Encoding.UTF8.GetBytes(input));
                return Convert.ToBase64String(data);
            }
        }
    }
}
 