﻿namespace ПП_3_курс
{
    partial class editUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            editUsersButton = new Button();
            choice = new Label();
            choiceUsers = new ComboBox();
            PasswordText = new TextBox();
            NameText = new TextBox();
            label4 = new Label();
            Name_author = new Label();
            AuthorID = new Label();
            RoleText = new ComboBox();
            SuspendLayout();
            // 
            // editUsersButton
            // 
            editUsersButton.BackColor = Color.Cyan;
            editUsersButton.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            editUsersButton.ForeColor = Color.White;
            editUsersButton.Location = new Point(21, 405);
            editUsersButton.Name = "editUsersButton";
            editUsersButton.Size = new Size(378, 33);
            editUsersButton.TabIndex = 43;
            editUsersButton.Text = "изменить";
            editUsersButton.UseVisualStyleBackColor = false;
            editUsersButton.Click += editUsersButton_Click;
            // 
            // choice
            // 
            choice.BackColor = Color.Cyan;
            choice.BorderStyle = BorderStyle.FixedSingle;
            choice.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            choice.ForeColor = Color.White;
            choice.Location = new Point(21, 12);
            choice.Name = "choice";
            choice.Size = new Size(378, 57);
            choice.TabIndex = 42;
            choice.Text = "Выберте пользователя для редиктирования";
            choice.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // choiceUsers
            // 
            choiceUsers.DropDownStyle = ComboBoxStyle.DropDownList;
            choiceUsers.Font = new Font("Segoe UI", 14.25F);
            choiceUsers.FormattingEnabled = true;
            choiceUsers.Location = new Point(21, 82);
            choiceUsers.Name = "choiceUsers";
            choiceUsers.Size = new Size(378, 33);
            choiceUsers.TabIndex = 41;
            choiceUsers.SelectedIndexChanged += choiceUsers_SelectedIndexChanged;
            // 
            // PasswordText
            // 
            PasswordText.Font = new Font("Segoe UI", 14.25F);
            PasswordText.Location = new Point(21, 256);
            PasswordText.Name = "PasswordText";
            PasswordText.Size = new Size(378, 33);
            PasswordText.TabIndex = 35;
            // 
            // NameText
            // 
            NameText.Font = new Font("Segoe UI", 14.25F);
            NameText.Location = new Point(21, 170);
            NameText.Name = "NameText";
            NameText.Size = new Size(378, 33);
            NameText.TabIndex = 34;
            // 
            // label4
            // 
            label4.BackColor = Color.Cyan;
            label4.BorderStyle = BorderStyle.FixedSingle;
            label4.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label4.ForeColor = Color.White;
            label4.Location = new Point(21, 303);
            label4.Name = "label4";
            label4.Size = new Size(378, 36);
            label4.TabIndex = 33;
            label4.Text = "Выберите роль";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Name_author
            // 
            Name_author.BackColor = Color.Cyan;
            Name_author.BorderStyle = BorderStyle.FixedSingle;
            Name_author.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Name_author.ForeColor = Color.White;
            Name_author.Location = new Point(21, 217);
            Name_author.Name = "Name_author";
            Name_author.Size = new Size(378, 36);
            Name_author.TabIndex = 32;
            Name_author.Text = "Введите пароль";
            Name_author.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // AuthorID
            // 
            AuthorID.BackColor = Color.Cyan;
            AuthorID.BorderStyle = BorderStyle.FixedSingle;
            AuthorID.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            AuthorID.ForeColor = Color.White;
            AuthorID.Location = new Point(21, 131);
            AuthorID.Name = "AuthorID";
            AuthorID.Size = new Size(378, 36);
            AuthorID.TabIndex = 31;
            AuthorID.Text = "Введите имя";
            AuthorID.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // RoleText
            // 
            RoleText.DropDownStyle = ComboBoxStyle.DropDownList;
            RoleText.Font = new Font("Segoe UI", 14.25F);
            RoleText.FormattingEnabled = true;
            RoleText.Items.AddRange(new object[] { "Администратор", "Клиент" });
            RoleText.Location = new Point(21, 355);
            RoleText.Name = "RoleText";
            RoleText.Size = new Size(378, 33);
            RoleText.TabIndex = 44;
            // 
            // editUsers
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(436, 478);
            Controls.Add(RoleText);
            Controls.Add(editUsersButton);
            Controls.Add(choice);
            Controls.Add(choiceUsers);
            Controls.Add(PasswordText);
            Controls.Add(NameText);
            Controls.Add(label4);
            Controls.Add(Name_author);
            Controls.Add(AuthorID);
            Name = "editUsers";
            Text = "editUsers";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox FaultTypeIDBox;
        private ComboBox DeviceIDBox;
        private Button editUsersButton;
        private Label choice;
        private ComboBox choiceUsers;
        private Label label1;
        private Label label2;
        private TextBox PasswordText;
        private TextBox NameText;
        private Label label4;
        private Label Name_author;
        private Label AuthorID;
        private ComboBox RoleText;
    }
}