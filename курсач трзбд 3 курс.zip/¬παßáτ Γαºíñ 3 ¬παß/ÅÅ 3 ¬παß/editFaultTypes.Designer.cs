﻿namespace ПП_3_курс
{
    partial class editFaultTypes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Member_edit_button = new Button();
            Description_edit_text = new TextBox();
            PhoneNumber = new Label();
            choice = new Label();
            choice_faultTypes = new ComboBox();
            SuspendLayout();
            // 
            // Member_edit_button
            // 
            Member_edit_button.BackColor = Color.Cyan;
            Member_edit_button.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Member_edit_button.ForeColor = Color.White;
            Member_edit_button.Location = new Point(24, 188);
            Member_edit_button.Name = "Member_edit_button";
            Member_edit_button.Size = new Size(376, 33);
            Member_edit_button.TabIndex = 26;
            Member_edit_button.Text = "изменить";
            Member_edit_button.UseVisualStyleBackColor = false;
            Member_edit_button.Click += Description_edit_button_Click;
            // 
            // Description_edit_text
            // 
            Description_edit_text.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Description_edit_text.Location = new Point(24, 138);
            Description_edit_text.Name = "Description_edit_text";
            Description_edit_text.Size = new Size(376, 33);
            Description_edit_text.TabIndex = 25;
            // 
            // PhoneNumber
            // 
            PhoneNumber.BackColor = Color.Cyan;
            PhoneNumber.BorderStyle = BorderStyle.FixedSingle;
            PhoneNumber.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            PhoneNumber.ForeColor = Color.White;
            PhoneNumber.Location = new Point(24, 104);
            PhoneNumber.Name = "PhoneNumber";
            PhoneNumber.Size = new Size(376, 31);
            PhoneNumber.TabIndex = 22;
            PhoneNumber.Text = "Введите ошибку";
            PhoneNumber.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // choice
            // 
            choice.BackColor = Color.Cyan;
            choice.BorderStyle = BorderStyle.FixedSingle;
            choice.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            choice.ForeColor = Color.White;
            choice.Location = new Point(24, 19);
            choice.Name = "choice";
            choice.Size = new Size(376, 31);
            choice.TabIndex = 19;
            choice.Text = "Выберте ошибку для редиктирования";
            choice.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // choice_faultTypes
            // 
            choice_faultTypes.DropDownStyle = ComboBoxStyle.DropDownList;
            choice_faultTypes.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            choice_faultTypes.FormattingEnabled = true;
            choice_faultTypes.Location = new Point(24, 53);
            choice_faultTypes.Name = "choice_faultTypes";
            choice_faultTypes.Size = new Size(376, 33);
            choice_faultTypes.TabIndex = 18;
            choice_faultTypes.SelectedIndexChanged += choice_faultTypes_SelectedIndexChanged;
            // 
            // editFaultTypes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(444, 287);
            Controls.Add(Member_edit_button);
            Controls.Add(Description_edit_text);
            Controls.Add(PhoneNumber);
            Controls.Add(choice);
            Controls.Add(choice_faultTypes);
            Name = "editFaultTypes";
            Text = "editFaultTypes";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Member_edit_button;
        private TextBox Description_edit_text;
        private Label PhoneNumber;
        private Label choice;
        private ComboBox choice_faultTypes;
    }
}