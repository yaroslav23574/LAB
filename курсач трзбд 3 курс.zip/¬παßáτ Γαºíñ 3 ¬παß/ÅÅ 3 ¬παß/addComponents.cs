﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace ПП_3_курс
{
    public partial class addComponents : Form
    {
        public event Action ComponentAdded;

        public addComponents()
        {
            InitializeComponent();
        }

        private void Add_components_Click(object sender, EventArgs e)
        {
            //получение значений из текстовых полей
            //int BookIDadd = int.Parse(ComponentID_text.Text);
            string Nameadd = Name_text.Text;
            int Priceadd = int.Parse(price_text.Text);
            int QuantityInStockadd = int.Parse(QuantityInStock_text.Text);

            // Подключение к базе данных
            string connectionString = "Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // SQL запрос для вставки данных
                string query = "INSERT INTO Components (Name, Price, QuantityInStock) VALUES (@Name, @Price, @QuantityInStock)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Добавление параметров к команде
                    //command.Parameters.AddWithValue("@BookID", BookIDadd);
                    command.Parameters.AddWithValue("@Name", Nameadd);
                    command.Parameters.AddWithValue("@Price", Priceadd);
                    command.Parameters.AddWithValue("@QuantityInStock", QuantityInStockadd);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            ComponentAdded.Invoke();
            Close();
        }
    }
}
