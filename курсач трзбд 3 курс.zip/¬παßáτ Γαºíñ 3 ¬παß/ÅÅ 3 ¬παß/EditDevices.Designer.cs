﻿namespace ПП_3_курс
{
    partial class EditDevices
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Member_edit_button = new Button();
            choice = new Label();
            choice_device = new ComboBox();
            label1 = new Label();
            ClientIDText = new ComboBox();
            ModelText = new TextBox();
            label2 = new Label();
            SuspendLayout();
            // 
            // Member_edit_button
            // 
            Member_edit_button.BackColor = Color.Cyan;
            Member_edit_button.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Member_edit_button.ForeColor = Color.White;
            Member_edit_button.Location = new Point(32, 308);
            Member_edit_button.Name = "Member_edit_button";
            Member_edit_button.Size = new Size(431, 33);
            Member_edit_button.TabIndex = 26;
            Member_edit_button.Text = "изменить";
            Member_edit_button.UseVisualStyleBackColor = false;
            Member_edit_button.Click += EditDevices_button_Click;
            // 
            // choice
            // 
            choice.BackColor = Color.Cyan;
            choice.BorderStyle = BorderStyle.FixedSingle;
            choice.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            choice.ForeColor = Color.White;
            choice.Location = new Point(32, 33);
            choice.Name = "choice";
            choice.Size = new Size(431, 31);
            choice.TabIndex = 19;
            choice.Text = "Выберте устройство для редиктирования";
            choice.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // choice_device
            // 
            choice_device.DropDownStyle = ComboBoxStyle.DropDownList;
            choice_device.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            choice_device.FormattingEnabled = true;
            choice_device.Location = new Point(32, 67);
            choice_device.Name = "choice_device";
            choice_device.Size = new Size(431, 33);
            choice_device.TabIndex = 18;
            choice_device.SelectedIndexChanged += choiceDevices_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.BackColor = Color.Cyan;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(32, 119);
            label1.Name = "label1";
            label1.Size = new Size(431, 31);
            label1.TabIndex = 27;
            label1.Text = "Введите номер клиента";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // ClientIDText
            // 
            ClientIDText.DropDownStyle = ComboBoxStyle.DropDownList;
            ClientIDText.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            ClientIDText.FormattingEnabled = true;
            ClientIDText.Location = new Point(32, 153);
            ClientIDText.Name = "ClientIDText";
            ClientIDText.Size = new Size(431, 33);
            ClientIDText.TabIndex = 28;
            // 
            // ModelText
            // 
            ModelText.Location = new Point(32, 254);
            ModelText.Name = "ModelText";
            ModelText.Size = new Size(431, 23);
            ModelText.TabIndex = 30;
            // 
            // label2
            // 
            label2.BackColor = Color.Cyan;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            label2.ForeColor = Color.White;
            label2.Location = new Point(32, 207);
            label2.Name = "label2";
            label2.Size = new Size(431, 35);
            label2.TabIndex = 29;
            label2.Text = "Введите модель устройства";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // EditDevices
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(500, 390);
            Controls.Add(ModelText);
            Controls.Add(label2);
            Controls.Add(ClientIDText);
            Controls.Add(label1);
            Controls.Add(Member_edit_button);
            Controls.Add(choice);
            Controls.Add(choice_device);
            Name = "EditDevices";
            Text = "редактирование устройства";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Member_edit_button;
        private Label choice;
        private ComboBox choice_device;
        private Label label1;
        private ComboBox ClientIDText;
        private TextBox ModelText;
        private Label label2;
    }
}