﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПП_3_курс
{
    public partial class editFaultTypes : Form
    {
        private SqlConnection connection;
        private DataTable FaultTypesTable;

        public event Action faultTypesEdited;

        public editFaultTypes()
        {
            InitializeComponent();
            editFaultTypes_Load();
        }
        //choice_faultTypes
        //Description_edit_text

        private void editFaultTypes_Load()
        {
            // Подключение к базе данных
            connection = new SqlConnection("Data Source=ADCLG1;Initial Catalog=Лекарев 329197-19!;Integrated Security=True;TrustServerCertificate=True;");
            string query = "SELECT FaultTypeID, TypeDescription FROM FaultTypes";
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            FaultTypesTable = new DataTable();
            adapter.Fill(FaultTypesTable);

            choice_faultTypes.DisplayMember = "FaultTypeID";
            choice_faultTypes.ValueMember = "FaultTypeID";
            choice_faultTypes.DataSource = FaultTypesTable;
        }

        private void choice_faultTypes_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Получаем выбранную строку
            DataRowView selectedRow = (DataRowView)choice_faultTypes.SelectedItem;
            // Заполняем текстовые поля
            Description_edit_text.Text = selectedRow["TypeDescription"].ToString();
        }

        private void Description_edit_button_Click(object sender, EventArgs e)
        {
            // Получаем выбранный MemberID
            int componentId = (int)choice_faultTypes.SelectedValue;

            // Обновляем данные в базе данных
            string updateQuery = "UPDATE FaultTypes SET TypeDescription = @TypeDescription WHERE FaultTypeID = @FaultTypeID";

            using (SqlCommand command = new SqlCommand(updateQuery, connection))
            {
                // Добавление параметров к команде
                command.Parameters.AddWithValue("@FaultTypeID", int.Parse(choice_faultTypes.Text));
                command.Parameters.AddWithValue("@TypeDescription", Description_edit_text.Text);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }

            editFaultTypes_Load();
            faultTypesEdited?.Invoke();
            Close();
        }
    }
}
